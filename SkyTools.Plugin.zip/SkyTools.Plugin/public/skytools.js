(function () {
  "use strict";

  var SKYTOOLS_UI_VERSION = "2026-07-29-stability-13";

  if (window.__skytoolsPluginLoaded && window.__skytoolsPluginVersion === SKYTOOLS_UI_VERSION) {
    return;
  }

  if (window.__skytoolsPluginLoaded && window.__skytoolsPluginVersion !== SKYTOOLS_UI_VERSION) {
    if (window.__skytoolsTickInterval) {
      window.clearInterval(window.__skytoolsTickInterval);
      window.__skytoolsTickInterval = null;
    }
    if (window.__skytoolsObserverTimer) {
      window.clearTimeout(window.__skytoolsObserverTimer);
      window.__skytoolsObserverTimer = null;
    }
    if (window.__skytoolsNavigationTimer) {
      window.clearTimeout(window.__skytoolsNavigationTimer);
      window.__skytoolsNavigationTimer = null;
    }
    if (window.__skytoolsObserver && window.__skytoolsObserver.disconnect) {
      window.__skytoolsObserver.disconnect();
      window.__skytoolsObserver = null;
    }
    var staleNodes = document.querySelectorAll(".skytools-panel,.skytools-fab-shell,.skytools-fab,.skytools-toast,.skytools-game-button,.skytools-game-indicators");
    for (var staleIndex = 0; staleIndex < staleNodes.length; staleIndex += 1) {
      staleNodes[staleIndex].remove();
    }
  }

  window.__skytoolsPluginLoaded = true;
  window.__skytoolsPluginVersion = SKYTOOLS_UI_VERSION;

  var PLUGIN_ID = "skytools-plugin";
  var API_ORDER_STORAGE_KEY = "SkyTools.ApiOrder";
  var THEME_STORAGE_KEY = "SkyTools.Theme";
  var THEME_STORAGE_KEYS = [THEME_STORAGE_KEY, "SkyTools.SelectedThemeId", "SkyTools.SelectedTheme"];
  var LANGUAGE_STORAGE_KEY = "SkyTools.Language";
  var PRELOAD_STORAGE_KEY = "SkyTools.PreloadAt";
  var INSTALLED_STORAGE_KEY = "SkyTools.InstalledSnapshot";
  var REFRESH_INSTALLED_ON_START_KEY = "SkyTools.RefreshInstalledOnStart";
  var FAB_COLLAPSED_STORAGE_KEY = "SkyTools.FabCollapsed";
  var FIX_CATALOG_STORAGE_KEY = "SkyTools.FixCatalogSnapshot";
  var FIX_CATALOG_RELEASE_URL = "https://api.github.com/repos/skyflarefox/fix/releases/tags/fix";
  var FIX_CATALOG_SNAPSHOT_TTL = 60000;
  var INSTALLED_SNAPSHOT_TTL = 600000;
  var LIBRARY_TAB_REFRESH_COOLDOWN = 30000;
  var DEFAULT_THEME = "official-orange";
  var DEFAULT_LANGUAGE = "auto";
  var SUPPORTED_LANGUAGES = [
    { id: "auto", label: "Automático do Windows" },
    { id: "en", label: "English" },
    { id: "pt-BR", label: "Português Brasileiro" },
    { id: "es", label: "Español" },
    { id: "ru", label: "Русский" }
  ];
  var SKYTOOLS_TRANSLATIONS = {
    "pt-BR": {
      "Home": "Início",
      "Fixes": "Correções",
      "Settings": "Configurações",
      " Steam integrated": "Steam integrado",
      "Steam integrated": "Steam integrado",
      "Library": "Biblioteca",
      "Default API": "API padrão",
      "Active": "Ativa",
      "Enabled": "Ativa",
      "Generic": "Genérica",
      "Generica": "Genérica",
      "Online": "Online",
      "Correção disponível": "Correção disponível",
      "Correção Online": "Correção Online",
      "Correção Genérica": "Correção Genérica",
      "Correção online disponível": "Correção online disponível",
      "Correção genérica disponível": "Correção genérica disponível",
      "Denuvo detectado": "Denuvo detectado",
      "EA app detectado": "EA app detectado",
      "Ubisoft Account detectado": "Ubisoft Account detectado",
      "Rockstar Games detectado": "Rockstar Games detectado",
      "Minimizar botão SkyTools": "Minimizar botão SkyTools",
      "Mostrar botão SkyTools": "Mostrar botão SkyTools",
      "Reiniciar Steam": "Reiniciar Steam",
      "Reiniciando Steam": "Reiniciando Steam",
      "Instalar jogo": "Instalar jogo",
      "Choose file": "Escolher arquivo",
      "No file selected": "Nenhum arquivo escolhido"
    },
    en: {
      "A ação falhou.": "The action failed.",
      "Ação concluída.": "Action completed.",
      "Abra uma página de jogo para adicionar.": "Open a game page to add it.",
      "A ação atual terminar.": "current action to finish.",
      "A aplicação da correção não respondeu a tempo.": "Applying the fix timed out.",
      "A URL da API precisa conter <appid>.": "The API URL must contain <appid>.",
      "Adicionar": "Add",
      "Adicionar API": "Add API",
      "Adicionar jogo": "Add game",
      "Adicionar jogo por AppID": "Add game by AppID",
      "Adicionar via SkyTools": "Add with SkyTools",
      "Minimizar botão SkyTools": "Minimize SkyTools button",
      "Mostrar botão SkyTools": "Show SkyTools button",
      "Adicionando este jogo via SkyTools": "Adding this game with SkyTools",
      "Adicionando jogo": "Adding game",
      "Adicionando...": "Adding...",
      "Aguardando uma ação.": "Waiting for an action.",
      "Aguarde a ação atual terminar.": "Wait for the current action to finish.",
      "Aguarde a adição terminar.": "Wait for the add action to finish.",
      "Aplicando Correção": "Applying Fix",
      "Aplicar na pasta do jogo": "Apply to game folder",
      "APIs": "APIs",
      "APIs de download": "Download APIs",
      "API key": "API key",
      "API padrão": "Built-in API",
      "API personalizada": "Custom API",
      "API personalizada {count}": "Custom API {count}",
      "API sem nome": "Unnamed API",
      "App atual": "Current app",
      "AppID inválido.": "Invalid AppID.",
      "Arquivo de backup": "Backup file",
      "Arrastar para ordenar": "Drag to reorder",
      "Arraste para definir a ordem de tentativa.": "Drag to set the retry order.",
      "Automático do Windows": "Windows automatic",
      "Ativa": "Enabled",
      "Ativar SkyTools": "Enable SkyTools",
      "Ativar SteamTools": "Enable SteamTools",
      "Ativando SkyTools": "Enabling SkyTools",
      "Ativando SteamTools": "Enabling SteamTools",
      "Atualizar": "Refresh",
      "Atualizando jogos e catálogo do GitHub.": "Updating games and the GitHub catalog.",
      "Backup": "Backup",
      "Biblioteca": "Library",
      "Biblioteca carregada": "Library loaded",
      "Baixando e instalando manifests": "Downloading and installing manifests",
      "Buscar correções": "Search fixes",
      "Buscar jogo instalado": "Search installed game",
      "Buscar na biblioteca": "Search library",
      "Buscar por jogo instalado": "Search by installed game",
      "Buscando correções": "Searching fixes",
      "Buscando correções Sky": "Searching Sky fixes",
      "Cache da Steam limpo e Steam reiniciada.": "Steam cache cleared and Steam restarted.",
      "Carregando APIs...": "Loading APIs...",
      "Carregando APIs": "Loading APIs",
      "Carregando biblioteca": "Loading library",
      "Carregando jogos adicionados.": "Loading added games.",
      "Carregando jogos instalados": "Loading installed games",
      "Carregando jogos instalados...": "Loading installed games...",
      "Carregando status": "Loading status",
      "Carregue um arquivo de backup primeiro.": "Load a backup file first.",
      "Carregue um backup": "Load a backup",
      "Configurações": "Settings",
      "Coletando configurações": "Collecting settings",
      "Concluído": "Done",
      "Correção Sky Aplicada.": "Sky fix applied.",
      "Correção disponível": "Fix available",
      "Correção Online": "Online Fix",
      "Correção Genérica": "Generic Fix",
      "Correção online disponível": "Online fix available",
      "Correção genérica disponível": "Generic fix available",
      "Denuvo detectado": "Denuvo detected",
      "EA app detectado": "EA app detected",
      "Ubisoft Account detectado": "Ubisoft Account detected",
      "Rockstar Games detectado": "Rockstar Games detected",
      "Correções": "Fixes",
      "Correções para jogo": "Game fixes",
      "Desativada": "Disabled",
      "Detectando": "Detecting",
      "Disponível em páginas de jogo": "Available on game pages",
      "Digite nome ou AppID": "Type name or AppID",
      "Digite o AppID do jogo": "Enter the game's AppID",
      "Editar API": "Edit API",
      "Editar API": "Edit API",
      "Encapsular URL.": "Wrap URL.",
      "Executando correção externa...": "Running external fix...",
      "Executando em segundo plano.": "Running in the background.",
      "Executando em segundo plano...": "Running in the background...",
      "Excluir API": "Delete API",
      "Exportando backup": "Exporting backup",
      "Exportar": "Export",
      "Exportar backup": "Export backup",
      "Falha": "Failed",
      "Fechar": "Close",
      "Reiniciar Steam": "Restart Steam",
      "Reiniciando Steam": "Restarting Steam",
      "Fonte": "Source",
      "Genérica": "Generic",
      "Generic": "Generic",
      "HTTP indisponível": "HTTP unavailable",
      "HTTP sucesso": "HTTP success",
      "Idioma": "Language",
      "Idioma aplicado": "Language applied",
      "Idioma inválido.": "Invalid language.",
      "Informe um nome para a API.": "Enter an API name.",
      "Início": "Home",
      "Instalar jogo": "Install game",
      "Instalar integração Steam": "Install Steam integration",
      "Instalar manifests na Steam": "Install manifests in Steam",
      "Integração": "Integration",
      "Integracao": "Integration",
      "Jogos instalados": "Installed games",
      "Jogos na biblioteca": "Games in library",
      "Jogo atual": "Current game",
      "Link copiado.": "Link copied.",
      "Link indisponível.": "Link unavailable.",
      "Lista de correções atualizada.": "Fix list updated.",
      "Nome": "Name",
      "Nenhum": "None",
      "Nenhum backup carregado.": "No backup loaded.",
      "Nenhum arquivo escolhido": "No file selected",
      "Nenhuma página de jogo detectada.": "No game page detected.",
      "Nenhum jogo aberto": "No game open",
      "Nenhum jogo carregado ainda.": "No games loaded yet.",
      "Nenhum jogo encontrado com esse filtro.": "No games found with this filter.",
      "Nenhum jogo instalado encontrado nas bibliotecas Steam.": "No installed games found in Steam libraries.",
      "Nenhuma API configurada.": "No APIs configured.",
      "Nenhuma correção Sky carregada.": "No Sky fixes loaded.",
      "Não foi possível gravar settings.json.": "Could not write settings.json.",
      "Não foi possível salvar o idioma.": "Could not save the language.",
      "Não foi possível salvar para a próxima inicialização.": "Could not save for the next startup.",
      "O idioma não foi persistido em settings.json.": "The language was not persisted in settings.json.",
      "Ordem salva": "Order saved",
      "Oceano ciano": "Cyan ocean",
      "Oficial laranja": "Official orange",
      "Online": "Online",
      "Pacote não suportado": "Unsupported package",
      "Preferência salva.": "Preference saved.",
      "A prioridade das APIs foi atualizada.": "The API priority was updated.",
      "Grafite lima": "Lime graphite",
      "Processando": "Processing",
      "Pronto": "Ready",
      "Proxy": "Proxy",
      "Remover correção e verificar integridade": "Remove fix and verify integrity",
      "Remover da Steam": "Remove from Steam",
      "Remover este jogo da biblioteca SkyTools": "Remove this game from the SkyTools library",
      "Remover via SkyTools": "Remove with SkyTools",
      "Removendo API": "Removing API",
      "Removendo correção": "Removing fix",
      "Removendo jogo": "Removing game",
      "Configurar jogo": "Configure game",
      "Versão do jogo": "Game version",
      "DLCs do Lua": "Lua DLCs",
      "Nenhuma DLC encontrada.": "No DLC found.",
      "Salvar configurações": "Save settings",
      "Salvando configurações": "Saving settings",
      "Configurações salvas.": "Settings saved.",
      "Informe DepotID e ManifestID juntos.": "Enter DepotID and ManifestID together.",
      "DepotID inválido.": "Invalid DepotID.",
      "ManifestID inválido.": "Invalid ManifestID.",
      "Arquivo Lua do jogo não encontrado.": "The game's Lua file was not found.",
      "Não foi possível salvar as configurações do jogo.": "Could not save the game settings.",
      "Travar atualizações": "Lock updates",
      "Destravar atualizações": "Unlock updates",
      "Travando atualizações": "Locking updates",
      "Destravando atualizações": "Unlocking updates",
      "Atualizações travadas.": "Updates locked.",
      "Atualizações destravadas.": "Updates unlocked.",
      "Restaurando backup": "Restoring backup",
      "Restaurar ausentes": "Restore missing",
      "Rubi brasa": "Ruby ember",
	  "Rosa Shock": "pink rose",
      "Resultados": "Results",
      "Salvar API": "Save API",
      "Salvar biblioteca em JSON": "Save library as JSON",
      "Salvando API": "Saving API",
      "Salvando idioma": "Saving language",
      "Salvando ordem": "Saving order",
      "Salvando preferências": "Saving preferences",
      "Sem dados ainda.": "No data yet.",
      "Steam integrado": "Steam integrated",
      "SkyTools carregado.": "SkyTools loaded.",
      "Sincronizando com o backend...": "Syncing with the backend...",
      "Steam não encontrada.": "Steam not found.",
      "Tema": "Theme",
      "Tema aplicado": "Theme applied",
      "Tema não aplicado": "Theme not applied",
      "Tema selecionado.": "Selected theme.",
      "URL da API": "API URL",
      "URL do proxy": "Proxy URL",
      "URL não configurada": "URL not configured",
      "Escolher arquivo": "Choose file",
      "Home": "Home",
      "Fixes": "Fixes",
      "Settings": "Settings",
      "Biblioteca": "Library",
      "Steam integrated": "Steam integrated",
      "Use <appid> na URL. Use <apikey> quando a fonte exigir chave.": "Use <appid> in the URL. Use <apikey> when the source requires a key.",
      "Usar nas instalações.": "Use during installs.",
      "Voltando ao tema oficial.": "Returning to the official theme."
    },
    es: {
      "A ação falhou.": "La acción falló.",
      "Ação concluída.": "Acción completada.",
      "Abra uma página de jogo para adicionar.": "Abre una página de juego para añadirlo.",
      "A aplicação da correção não respondeu a tempo.": "La aplicación de la corrección agotó el tiempo.",
      "A URL da API precisa conter <appid>.": "La URL de la API debe contener <appid>.",
      "Adicionar": "Añadir",
      "Adicionar API": "Añadir API",
      "Adicionar jogo": "Añadir juego",
      "Adicionar jogo por AppID": "Añadir juego por AppID",
      "Adicionar via SkyTools": "Añadir con SkyTools",
      "Minimizar botão SkyTools": "Minimizar botón SkyTools",
      "Mostrar botão SkyTools": "Mostrar botón SkyTools",
      "Adicionando este jogo via SkyTools": "Añadiendo este juego con SkyTools",
      "Adicionando jogo": "Añadiendo juego",
      "Adicionando...": "Añadiendo...",
      "Aguardando uma ação.": "Esperando una acción.",
      "Aguarde a ação atual terminar.": "Espera a que termine la acción actual.",
      "Aguarde a adição terminar.": "Espera a que termine la adición.",
      "Aplicando Correção": "Aplicando corrección",
      "Aplicar na pasta do jogo": "Aplicar en la carpeta del juego",
      "APIs de download": "APIs de descarga",
      "API padrão": "API predeterminada",
      "API personalizada": "API personalizada",
      "API personalizada {count}": "API personalizada {count}",
      "API sem nome": "API sin nombre",
      "App atual": "App actual",
      "AppID inválido.": "AppID inválido.",
      "Arquivo de backup": "Archivo de backup",
      "Arrastar para ordenar": "Arrastrar para ordenar",
      "Arraste para definir a ordem de tentativa.": "Arrastra para definir el orden de intento.",
      "Automático do Windows": "Automático de Windows",
      "Ativa": "Activa",
      "Ativar SkyTools": "Activar SkyTools",
      "Ativar SteamTools": "Activar SteamTools",
      "Ativando SkyTools": "Activando SkyTools",
      "Ativando SteamTools": "Activando SteamTools",
      "Atualizar": "Actualizar",
      "Atualizando jogos e catálogo do GitHub.": "Actualizando juegos y el catálogo de GitHub.",
      "Backup": "Backup",
      "Biblioteca": "Biblioteca",
      "Biblioteca carregada": "Biblioteca cargada",
      "Baixando e instalando manifests": "Descargando e instalando manifests",
      "Buscar correções": "Buscar correcciones",
      "Buscar jogo instalado": "Buscar juego instalado",
      "Buscar na biblioteca": "Buscar en la biblioteca",
      "Buscar por jogo instalado": "Buscar por juego instalado",
      "Buscando correções": "Buscando correcciones",
      "Buscando correções Sky": "Buscando correcciones Sky",
      "Cache da Steam limpo e Steam reiniciada.": "Caché de Steam limpiada y Steam reiniciado.",
      "Carregando APIs...": "Cargando APIs...",
      "Carregando APIs": "Cargando APIs",
      "Carregando biblioteca": "Cargando biblioteca",
      "Carregando jogos adicionados.": "Cargando juegos añadidos.",
      "Carregando jogos instalados": "Cargando juegos instalados",
      "Carregando jogos instalados...": "Cargando juegos instalados...",
      "Carregando status": "Cargando estado",
      "Carregue um arquivo de backup primeiro.": "Carga primero un archivo de backup.",
      "Carregue um backup": "Carga un backup",
      "Configurações": "Configuración",
      "Coletando configurações": "Recopilando configuración",
      "Concluído": "Completado",
      "Correção Sky Aplicada.": "Corrección Sky aplicada.",
      "Correção disponível": "Corrección disponible",
      "Correção Online": "Corrección online",
      "Correção Genérica": "Corrección genérica",
      "Correção online disponível": "Corrección online disponible",
      "Correção genérica disponível": "Corrección genérica disponible",
      "Denuvo detectado": "Denuvo detectado",
      "EA app detectado": "EA app detectado",
      "Ubisoft Account detectado": "Ubisoft Account detectado",
      "Rockstar Games detectado": "Rockstar Games detectado",
      "Correções": "Correcciones",
      "Correções para jogo": "Correcciones del juego",
      "Desativada": "Desactivada",
      "Detectando": "Detectando",
      "Disponível em páginas de jogo": "Disponible en páginas de juegos",
      "Digite nome ou AppID": "Escribe nombre o AppID",
      "Digite o AppID do jogo": "Introduce el AppID del juego",
      "Editar API": "Editar API",
      "Encapsular URL.": "Encapsular URL.",
      "Executando correção externa...": "Ejecutando corrección externa...",
      "Executando em segundo plano.": "Ejecutando en segundo plano.",
      "Executando em segundo plano...": "Ejecutando en segundo plano...",
      "Excluir API": "Eliminar API",
      "Exportando backup": "Exportando backup",
      "Exportar": "Exportar",
      "Exportar backup": "Exportar backup",
      "Falha": "Error",
      "Fechar": "Cerrar",
      "Reiniciar Steam": "Reiniciar Steam",
      "Reiniciando Steam": "Reiniciando Steam",
      "Fonte": "Fuente",
      "Genérica": "Genérica",
      "Generic": "Genérica",
      "HTTP indisponível": "HTTP no disponible",
      "HTTP sucesso": "HTTP éxito",
      "Idioma": "Idioma",
      "Idioma aplicado": "Idioma aplicado",
      "Idioma inválido.": "Idioma inválido.",
      "Informe um nome para a API.": "Introduce un nombre para la API.",
      "Início": "Inicio",
      "Instalar jogo": "Instalar juego",
      "Instalar integração Steam": "Instalar integración Steam",
      "Instalar manifests na Steam": "Instalar manifests en Steam",
      "Integração": "Integración",
      "Integracao": "Integración",
      "Jogos instalados": "Juegos instalados",
      "Jogos na biblioteca": "Juegos en la biblioteca",
      "Jogo atual": "Juego actual",
      "Link copiado.": "Enlace copiado.",
      "Link indisponível.": "Enlace no disponible.",
      "Lista de correções atualizada.": "Lista de correcciones actualizada.",
      "Nome": "Nombre",
      "Nenhum": "Ninguno",
      "Nenhum backup carregado.": "Ningún backup cargado.",
      "Nenhum arquivo escolhido": "Ningún archivo elegido",
      "Nenhuma página de jogo detectada.": "No se detectó ninguna página de juego.",
      "Nenhum jogo aberto": "Ningún juego abierto",
      "Nenhum jogo carregado ainda.": "No hay juegos cargados todavía.",
      "Nenhum jogo encontrado com esse filtro.": "No se encontraron juegos con este filtro.",
      "Nenhum jogo instalado encontrado nas bibliotecas Steam.": "No se encontraron juegos instalados en las bibliotecas de Steam.",
      "Nenhuma API configurada.": "Ninguna API configurada.",
      "Nenhuma correção Sky carregada.": "Ninguna corrección Sky cargada.",
      "Não foi possível gravar settings.json.": "No se pudo escribir settings.json.",
      "Não foi possível salvar o idioma.": "No se pudo guardar el idioma.",
      "Não foi possível salvar para a próxima inicialização.": "No se pudo guardar para el próximo inicio.",
      "O idioma não foi persistido em settings.json.": "El idioma no se guardó en settings.json.",
      "Ordem salva": "Orden guardado",
      "Oceano ciano": "Océano cian",
      "Oficial laranja": "Naranja oficial",
      "Online": "Online",
      "Pacote não suportado": "Paquete no compatible",
      "Preferência salva.": "Preferencia guardada.",
      "A prioridade das APIs foi atualizada.": "La prioridad de las APIs se actualizó.",
      "Grafite lima": "Grafito lima",
      "Processando": "Procesando",
      "Pronto": "Listo",
      "Proxy": "Proxy",
      "Remover correção e verificar integridade": "Eliminar corrección y verificar integridad",
      "Remover da Steam": "Eliminar de Steam",
      "Remover este jogo da biblioteca SkyTools": "Eliminar este juego de la biblioteca SkyTools",
      "Remover via SkyTools": "Eliminar con SkyTools",
      "Removendo API": "Eliminando API",
      "Removendo correção": "Eliminando corrección",
      "Removendo jogo": "Eliminando juego",
      "Configurar jogo": "Configurar juego",
      "Versão do jogo": "Versión del juego",
      "DLCs do Lua": "DLCs del Lua",
      "Nenhuma DLC encontrada.": "No se encontró ningún DLC.",
      "Salvar configurações": "Guardar configuración",
      "Salvando configurações": "Guardando configuración",
      "Configurações salvas.": "Configuración guardada.",
      "Informe DepotID e ManifestID juntos.": "Introduce DepotID y ManifestID juntos.",
      "DepotID inválido.": "DepotID no válido.",
      "ManifestID inválido.": "ManifestID no válido.",
      "Arquivo Lua do jogo não encontrado.": "No se encontró el archivo Lua del juego.",
      "Não foi possível salvar as configurações do jogo.": "No se pudo guardar la configuración del juego.",
      "Travar atualizações": "Bloquear actualizaciones",
      "Destravar atualizações": "Desbloquear actualizaciones",
      "Travando atualizações": "Bloqueando actualizaciones",
      "Destravando atualizações": "Desbloqueando actualizaciones",
      "Atualizações travadas.": "Actualizaciones bloqueadas.",
      "Atualizações destravadas.": "Actualizaciones desbloqueadas.",
      "Restaurando backup": "Restaurando backup",
      "Restaurar ausentes": "Restaurar ausentes",
      "Rubi brasa": "Rubí brasa",
	  "Rosa Shock": "Rosa Shock",
      "Resultados": "Resultados",
      "Salvar API": "Guardar API",
      "Salvar biblioteca em JSON": "Guardar biblioteca en JSON",
      "Salvando API": "Guardando API",
      "Salvando idioma": "Guardando idioma",
      "Salvando ordem": "Guardando orden",
      "Salvando preferências": "Guardando preferencias",
      "Sem dados ainda.": "Sin datos todavía.",
      "Steam integrado": "Steam integrado",
      "SkyTools carregado.": "SkyTools cargado.",
      "Sincronizando com o backend...": "Sincronizando con el backend...",
      "Steam não encontrada.": "Steam no encontrada.",
      "Tema": "Tema",
      "Tema aplicado": "Tema aplicado",
      "Tema não aplicado": "Tema no aplicado",
      "Tema selecionado.": "Tema seleccionado.",
      "URL da API": "URL de la API",
      "URL do proxy": "URL del proxy",
      "URL não configurada": "URL no configurada",
      "Escolher arquivo": "Elegir archivo",
      "Home": "Inicio",
      "Fixes": "Correcciones",
      "Settings": "Configuración",
      "Steam integrated": "Steam integrado",
      "Use <appid> na URL. Use <apikey> quando a fonte exigir chave.": "Usa <appid> en la URL. Usa <apikey> cuando la fuente requiera una clave.",
      "Usar nas instalações.": "Usar en las instalaciones.",
      "Voltando ao tema oficial.": "Volviendo al tema oficial."
    },
    ru: {
      "A ação falhou.": "Действие не выполнено.",
      "Ação concluída.": "Действие завершено.",
      "Abra uma página de jogo para adicionar.": "Откройте страницу игры, чтобы добавить ее.",
      "A aplicação da correção não respondeu a tempo.": "Применение исправления не ответило вовремя.",
      "A URL da API precisa conter <appid>.": "URL API должен содержать <appid>.",
      "Adicionar": "Добавить",
      "Adicionar API": "Добавить API",
      "Adicionar jogo": "Добавить игру",
      "Adicionar jogo por AppID": "Добавить игру по AppID",
      "Adicionar via SkyTools": "Добавить через SkyTools",
      "Minimizar botão SkyTools": "Свернуть кнопку SkyTools",
      "Mostrar botão SkyTools": "Показать кнопку SkyTools",
      "Adicionando este jogo via SkyTools": "Добавление этой игры через SkyTools",
      "Adicionando jogo": "Добавление игры",
      "Adicionando...": "Добавление...",
      "Aguardando uma ação.": "Ожидание действия.",
      "Aguarde a ação atual terminar.": "Дождитесь завершения текущего действия.",
      "Aguarde a adição terminar.": "Дождитесь завершения добавления.",
      "Aplicando Correção": "Применение исправления",
      "Aplicar na pasta do jogo": "Применить в папке игры",
      "APIs de download": "API загрузки",
      "API padrão": "Встроенный API",
      "API personalizada": "Пользовательский API",
      "API personalizada {count}": "Пользовательский API {count}",
      "API sem nome": "API без имени",
      "App atual": "Текущее приложение",
      "AppID inválido.": "Недействительный AppID.",
      "Arquivo de backup": "Файл резервной копии",
      "Arrastar para ordenar": "Перетащите для сортировки",
      "Arraste para definir a ordem de tentativa.": "Перетащите, чтобы задать порядок попыток.",
      "Automático do Windows": "Автоматически из Windows",
      "Ativa": "Включена",
      "Ativar SkyTools": "Включить SkyTools",
      "Ativar SteamTools": "Включить SteamTools",
      "Ativando SkyTools": "Включение SkyTools",
      "Ativando SteamTools": "Включение SteamTools",
      "Atualizar": "Обновить",
      "Atualizando jogos e catálogo do GitHub.": "Обновление игр и каталога GitHub.",
      "Backup": "Резервная копия",
      "Biblioteca": "Библиотека",
      "Biblioteca carregada": "Библиотека загружена",
      "Baixando e instalando manifests": "Загрузка и установка манифестов",
      "Buscar correções": "Искать исправления",
      "Buscar jogo instalado": "Искать установленную игру",
      "Buscar na biblioteca": "Поиск в библиотеке",
      "Buscar por jogo instalado": "Поиск по установленной игре",
      "Buscando correções": "Поиск исправлений",
      "Buscando correções Sky": "Поиск исправлений Sky",
      "Cache da Steam limpo e Steam reiniciada.": "Кэш Steam очищен, Steam перезапущен.",
      "Carregando APIs...": "Загрузка API...",
      "Carregando APIs": "Загрузка API",
      "Carregando biblioteca": "Загрузка библиотеки",
      "Carregando jogos adicionados.": "Загрузка добавленных игр.",
      "Carregando jogos instalados": "Загрузка установленных игр",
      "Carregando jogos instalados...": "Загрузка установленных игр...",
      "Carregando status": "Загрузка статуса",
      "Carregue um arquivo de backup primeiro.": "Сначала загрузите файл резервной копии.",
      "Carregue um backup": "Загрузите резервную копию",
      "Configurações": "Настройки",
      "Coletando configurações": "Сбор настроек",
      "Concluído": "Готово",
      "Correção Sky Aplicada.": "Исправление Sky применено.",
      "Correção disponível": "Доступно исправление",
      "Correção Online": "Онлайн-исправление",
      "Correção Genérica": "Общее исправление",
      "Correção online disponível": "Доступно онлайн-исправление",
      "Correção genérica disponível": "Доступно общее исправление",
      "Denuvo detectado": "Обнаружен Denuvo",
      "EA app detectado": "Обнаружен EA app",
      "Ubisoft Account detectado": "Обнаружен Ubisoft Account",
      "Rockstar Games detectado": "Обнаружен Rockstar Games",
      "Correções": "Исправления",
      "Correções para jogo": "Исправления для игры",
      "Desativada": "Отключена",
      "Detectando": "Определение",
      "Disponível em páginas de jogo": "Доступно на страницах игр",
      "Digite nome ou AppID": "Введите имя или AppID",
      "Digite o AppID do jogo": "Введите AppID игры",
      "Editar API": "Редактировать API",
      "Encapsular URL.": "Обернуть URL.",
      "Executando correção externa...": "Запуск внешнего исправления...",
      "Executando em segundo plano.": "Выполняется в фоне.",
      "Executando em segundo plano...": "Выполняется в фоне...",
      "Excluir API": "Удалить API",
      "Exportando backup": "Экспорт резервной копии",
      "Exportar": "Экспорт",
      "Exportar backup": "Экспорт резервной копии",
      "Falha": "Ошибка",
      "Fechar": "Закрыть",
      "Reiniciar Steam": "Перезапустить Steam",
      "Reiniciando Steam": "Перезапуск Steam",
      "Fonte": "Источник",
      "Genérica": "Общее",
      "Generic": "Общее",
      "HTTP indisponível": "HTTP недоступен",
      "HTTP sucesso": "HTTP успех",
      "Idioma": "Язык",
      "Idioma aplicado": "Язык применен",
      "Idioma inválido.": "Недействительный язык.",
      "Informe um nome para a API.": "Введите имя API.",
      "Início": "Главная",
      "Instalar jogo": "Установить игру",
      "Instalar integração Steam": "Установить интеграцию Steam",
      "Instalar manifests na Steam": "Установить манифесты в Steam",
      "Integração": "Интеграция",
      "Integracao": "Интеграция",
      "Jogos instalados": "Установленные игры",
      "Jogos na biblioteca": "Игры в библиотеке",
      "Jogo atual": "Текущая игра",
      "Link copiado.": "Ссылка скопирована.",
      "Link indisponível.": "Ссылка недоступна.",
      "Lista de correções atualizada.": "Список исправлений обновлен.",
      "Nome": "Имя",
      "Nenhum": "Нет",
      "Nenhum backup carregado.": "Резервная копия не загружена.",
      "Nenhum arquivo escolhido": "Файл не выбран",
      "Nenhuma página de jogo detectada.": "Страница игры не обнаружена.",
      "Nenhum jogo aberto": "Игра не открыта",
      "Nenhum jogo carregado ainda.": "Игры еще не загружены.",
      "Nenhum jogo encontrado com esse filtro.": "Игры по этому фильтру не найдены.",
      "Nenhum jogo instalado encontrado nas bibliotecas Steam.": "Установленные игры в библиотеках Steam не найдены.",
      "Nenhuma API configurada.": "API не настроены.",
      "Nenhuma correção Sky carregada.": "Исправления Sky не загружены.",
      "Não foi possível gravar settings.json.": "Не удалось записать settings.json.",
      "Não foi possível salvar o idioma.": "Не удалось сохранить язык.",
      "Não foi possível salvar para a próxima inicialização.": "Не удалось сохранить для следующего запуска.",
      "O idioma não foi persistido em settings.json.": "Язык не был сохранен в settings.json.",
      "Ordem salva": "Порядок сохранен",
      "Oceano ciano": "Циановый океан",
      "Oficial laranja": "Официальный оранжевый",
      "Online": "Онлайн",
      "Pacote não suportado": "Пакет не поддерживается",
      "Preferência salva.": "Настройка сохранена.",
      "A prioridade das APIs foi atualizada.": "Приоритет API обновлен.",
      "Grafite lima": "Графитовый лайм",
      "Processando": "Обработка",
      "Pronto": "Готово",
      "Proxy": "Прокси",
      "Remover correção e verificar integridade": "Удалить исправление и проверить целостность",
      "Remover da Steam": "Удалить из Steam",
      "Remover este jogo da biblioteca SkyTools": "Удалить эту игру из библиотеки SkyTools",
      "Remover via SkyTools": "Удалить через SkyTools",
      "Removendo API": "Удаление API",
      "Removendo correção": "Удаление исправления",
      "Removendo jogo": "Удаление игры",
      "Configurar jogo": "Настроить игру",
      "Versão do jogo": "Версия игры",
      "DLCs do Lua": "DLC из Lua",
      "Nenhuma DLC encontrada.": "DLC не найдены.",
      "Salvar configurações": "Сохранить настройки",
      "Salvando configurações": "Сохранение настроек",
      "Configurações salvas.": "Настройки сохранены.",
      "Informe DepotID e ManifestID juntos.": "Введите DepotID и ManifestID вместе.",
      "DepotID inválido.": "Недопустимый DepotID.",
      "ManifestID inválido.": "Недопустимый ManifestID.",
      "Arquivo Lua do jogo não encontrado.": "Lua-файл игры не найден.",
      "Não foi possível salvar as configurações do jogo.": "Не удалось сохранить настройки игры.",
      "Travar atualizações": "Заблокировать обновления",
      "Destravar atualizações": "Разблокировать обновления",
      "Travando atualizações": "Блокировка обновлений",
      "Destravando atualizações": "Разблокировка обновлений",
      "Atualizações travadas.": "Обновления заблокированы.",
      "Atualizações destravadas.": "Обновления разблокированы.",
      "Restaurando backup": "Восстановление резервной копии",
      "Restaurar ausentes": "Восстановить отсутствующие",
      "Rubi brasa": "Рубиновый жар",
	  "Rosa Shock": "шокирующий розовый",
      "Resultados": "Результаты",
      "Salvar API": "Сохранить API",
      "Salvar biblioteca em JSON": "Сохранить библиотеку в JSON",
      "Salvando API": "Сохранение API",
      "Salvando idioma": "Сохранение языка",
      "Salvando ordem": "Сохранение порядка",
      "Salvando preferências": "Сохранение настроек",
      "Sem dados ainda.": "Данных пока нет.",
      "Steam integrado": "Steam интегрирован",
      "SkyTools carregado.": "SkyTools загружен.",
      "Sincronizando com o backend...": "Синхронизация с backend...",
      "Steam não encontrada.": "Steam не найден.",
      "Tema": "Тема",
      "Tema aplicado": "Тема применена",
      "Tema não aplicado": "Тема не применена",
      "Tema selecionado.": "Выбранная тема.",
      "URL da API": "URL API",
      "URL do proxy": "URL прокси",
      "URL não configurada": "URL не настроен",
      "Escolher arquivo": "Выбрать файл",
      "Home": "Главная",
      "Fixes": "Исправления",
      "Settings": "Настройки",
      "Steam integrated": "Steam интегрирован",
      "Use <appid> na URL. Use <apikey> quando a fonte exigir chave.": "Используйте <appid> в URL. Используйте <apikey>, если источник требует ключ.",
      "Usar nas instalações.": "Использовать при установке.",
      "Voltando ao tema oficial.": "Возврат к официальной теме."
    }
  };
  var BUILT_IN_THEMES = [
    { id: DEFAULT_THEME, name: "Oficial laranja", file: "official-orange.css" },
    { id: "ocean-cyan", name: "Oceano ciano", file: "ocean-cyan.css" },
    { id: "graphite-lime", name: "Grafite lima", file: "graphite-lime.css" },
    { id: "ruby-ember", name: "Rubi brasa", file: "ruby-ember.css" },
    { id: "pink-rose", name: "Rosa Shock", file: "pink-rose.css" }
  ];
  var BUILT_IN_THEME_VARS = {
    "official-orange": {
      "bg": "#17120f", "bg-elevated": "rgba(28, 22, 18, 0.98)", "surface": "rgba(255, 255, 255, 0.035)", "surface-strong": "rgba(255, 255, 255, 0.045)", "surface-muted": "rgba(0, 0, 0, 0.16)", "surface-deep": "rgba(0, 0, 0, 0.28)", "text": "#ffffff", "text-soft": "#f6ddc5", "muted": "#d1a57d", "muted-strong": "#d7b28d", "brand-muted": "#d9ad83", "accent": "#e88914", "accent-strong": "#c24e12", "accent-alt": "#f59e0b", "accent-rgb": "255, 166, 77", "accent-strong-rgb": "194, 78, 18", "accent-text": "#ffd29a", "button-start": "#bf4b10", "button-end": "#e88914", "button-remove-start": "#9f3b0e", "button-remove-end": "#d86510", "success": "#34d399", "success-soft": "#7ee0a3", "danger": "#fb7185", "danger-soft": "#ff8a8a", "danger-text": "#ffb4a8", "warning": "#f2c94c"
    },
    "ocean-cyan": {
      "bg": "#101817", "bg-elevated": "rgba(17, 28, 28, 0.98)", "surface": "rgba(185, 255, 245, 0.04)", "surface-strong": "rgba(185, 255, 245, 0.07)", "surface-muted": "rgba(0, 0, 0, 0.18)", "surface-deep": "rgba(0, 0, 0, 0.32)", "text": "#f5fffd", "text-soft": "#c9f4ed", "muted": "#8ac9c1", "muted-strong": "#a5d8d1", "brand-muted": "#95d5ce", "accent": "#22d3ee", "accent-strong": "#0e7490", "accent-alt": "#14b8a6", "accent-rgb": "34, 211, 238", "accent-strong-rgb": "14, 116, 144", "accent-text": "#b9fbff", "button-start": "#0f766e", "button-end": "#0891b2", "button-remove-start": "#155e75", "button-remove-end": "#0e7490", "success": "#4ade80", "success-soft": "#86efac", "danger": "#fb7185", "danger-soft": "#fda4af", "danger-text": "#fecdd3", "warning": "#facc15"
    },
    "graphite-lime": {
      "bg": "#141611", "bg-elevated": "rgba(23, 26, 19, 0.98)", "surface": "rgba(222, 255, 171, 0.04)", "surface-strong": "rgba(222, 255, 171, 0.07)", "surface-muted": "rgba(0, 0, 0, 0.18)", "surface-deep": "rgba(0, 0, 0, 0.32)", "text": "#fbfff5", "text-soft": "#e2f7c0", "muted": "#bdd38f", "muted-strong": "#d0e5a6", "brand-muted": "#c4dd92", "accent": "#a3e635", "accent-strong": "#4d7c0f", "accent-alt": "#84cc16", "accent-rgb": "163, 230, 53", "accent-strong-rgb": "77, 124, 15", "accent-text": "#ecfccb", "button-start": "#3f6212", "button-end": "#65a30d", "button-remove-start": "#713f12", "button-remove-end": "#a16207", "success": "#22c55e", "success-soft": "#86efac", "danger": "#f87171", "danger-soft": "#fca5a5", "danger-text": "#fecaca", "warning": "#fbbf24"
    },
    "ruby-ember": {
      "bg": "#180f13", "bg-elevated": "rgba(30, 18, 23, 0.98)", "surface": "rgba(255, 214, 224, 0.04)", "surface-strong": "rgba(255, 214, 224, 0.07)", "surface-muted": "rgba(0, 0, 0, 0.17)", "surface-deep": "rgba(0, 0, 0, 0.31)", "text": "#fff8fa", "text-soft": "#ffd8df", "muted": "#dfa0aa", "muted-strong": "#efb5bf", "brand-muted": "#e6a4ae", "accent": "#fb7185", "accent-strong": "#be123c", "accent-alt": "#f97316", "accent-rgb": "251, 113, 133", "accent-strong-rgb": "190, 18, 60", "accent-text": "#ffe4e6", "button-start": "#9f1239", "button-end": "#e11d48", "button-remove-start": "#7f1d1d", "button-remove-end": "#b91c1c", "success": "#34d399", "success-soft": "#86efac", "danger": "#f43f5e", "danger-soft": "#fb7185", "danger-text": "#fecdd3", "warning": "#fbbf24"
    },
    "pink-rose": {
      "bg": "#1a0a14", "bg-elevated": "rgba(36, 12, 28, 0.98)", "surface": "rgba(255, 182, 217, 0.05)", "surface-strong": "rgba(255, 182, 217, 0.09)", "surface-muted": "rgba(0, 0, 0, 0.22)", "surface-deep": "rgba(0, 0, 0, 0.40)", "text": "#fff5f9", "text-soft": "#fce7f3", "muted": "#e895c0", "muted-strong": "#f4b8d7", "brand-muted": "#e382b6", "accent": "#f472b6", "accent-strong": "#db2777", "accent-alt": "#e879f9", "accent-rgb": "244, 114, 182", "accent-strong-rgb": "219, 39, 119", "accent-text": "#fdf2f8", "button-start": "#db2777", "button-end": "#f472b6", "button-remove-start": "#881337", "button-remove-end": "#be123c", "success": "#34d399", "success-soft": "#a7f3d0", "danger": "#f43f5e", "danger-soft": "#fb7185", "danger-text": "#ffe4e6", "warning": "#fbbf24"
    }
  };
  var state = {
    lastUrl: "",
    appid: "",
    appName: "",
    busy: false,
    pendingTab: "",
    bridgeCallTail: Promise.resolve(),
    bridgeCallMode: "",
    activeTab: "inicio",
    status: null,
    installed: null,
    fixGames: null,
    fixCatalog: null,
    fixAvailableMap: {},
    fixKindsMap: {},
    fixCatalogLoadedAt: 0,
    installedMap: {},
    installedLoadedAt: 0,
    installedLoading: false,
    fixGamesLoading: false,
    fixGamesPromise: null,
    fixCatalogLoading: false,
    fixCatalogPromise: null,
    storeFixCatalogLoading: false,
    storeFixCatalogPromise: null,
    nameCache: {},
    apis: null,
    themes: BUILT_IN_THEMES.slice(),
    themeId: readStoredTheme(),
    languageMode: readStoredLanguage(),
    themeRequestId: 0,
    themeCss: "",
    themeAppliedId: "",
    themeVars: null,
    apisLoading: false,
    apisPromise: null,
    startupPreloadStarted: false,
    apiForm: null,
    apiOrder: null,
    draggingApiId: "",
    pendingApiDrop: null,
    draggingPointerId: null,
    libraryQuery: "",
    installedPromise: null,
    backup: null,
    fixResults: null,
    fixQuery: "",
    fixVisibleCount: 80,
    fixMatchedCount: 0,
    selectedFixGame: null,
    lastResult: null,
    addAppIdInput: "",
    lastPageAppId: "",
    addingAppId: "",
    activityTitle: "Pronto",
    activityDetail: "Aguardando uma ação.",
    activityKind: "idle",
    fabCollapsed: readStoredFabCollapsed(),
    expandedGameSettingsAppId: "",
    gearSpinAppId: "",
    indicatorCatalogAppId: ""
  };
  hydrateInstalledSnapshot();

  var icons = {
    add: "f055",
    library: "f11b",
    api: "f233",
    fixes: "f0ad",
    online: "f0c2",
    denuvo: "f3ed",
    backup: "f019",
    repair: "f7d9",
    status: "f05a",
    settings: "f013",
    close: "f00d",
    chevronLeft: "f053",
    chevronRight: "f054",
    refresh: "f021",
    restart: "f2f9",
    download: "f019",
    check: "f058",
    error: "f071",
    spinner: "f110",
    folder: "f07b",
    list: "f03a",
    shield: "f3ed",
    trash: "f2ed",
    lock: "f023",
    lockOpen: "f3c1",
    gear: "f013",
    save: "f0c7",
    plug: "f1e6",
    pencil: "f303"
  };

  function icon(name, extraClass) {
    return '<i class="skytools-fa ' + (extraClass || "") + '">&#x' + (icons[name] || icons.status) + ';</i>';
  }

  function escapeHtml(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function normalizeLanguageId(value) {
    value = String(value || "").trim();
    if (!value) {
      return DEFAULT_LANGUAGE;
    }
    var lower = value.toLowerCase();
    if (lower === "pt" || lower === "pt-br" || lower === "pt_br") {
      return "pt-BR";
    }
    if (lower === "en" || lower.indexOf("en-") === 0) {
      return "en";
    }
    if (lower === "es" || lower.indexOf("es-") === 0) {
      return "es";
    }
    if (lower === "ru" || lower.indexOf("ru-") === 0) {
      return "ru";
    }
    if (lower === "auto" || lower === "system" || lower === "windows") {
      return "auto";
    }
    return DEFAULT_LANGUAGE;
  }

  function systemLanguageId() {
    var candidates = [];
    if (navigator.languages && navigator.languages.length) {
      candidates = Array.prototype.slice.call(navigator.languages);
    }
    candidates.push(navigator.language || navigator.userLanguage || "");
    for (var i = 0; i < candidates.length; i += 1) {
      var id = normalizeLanguageId(candidates[i]);
      if (id !== "auto") {
        return id;
      }
    }
    return "en";
  }

  function activeLanguageId() {
    var mode = normalizeLanguageId(state && state.languageMode || DEFAULT_LANGUAGE);
    return mode === "auto" ? systemLanguageId() : mode;
  }

  function languageLabel(id) {
    id = normalizeLanguageId(id);
    for (var i = 0; i < SUPPORTED_LANGUAGES.length; i += 1) {
      if (SUPPORTED_LANGUAGES[i].id === id) {
        return SUPPORTED_LANGUAGES[i].label;
      }
    }
    return SUPPORTED_LANGUAGES[0].label;
  }

  function t(text, vars) {
    text = String(text == null ? "" : text);
    var lang = activeLanguageId();
    var value = (SKYTOOLS_TRANSLATIONS[lang] && SKYTOOLS_TRANSLATIONS[lang][text]) || text;
    if (vars) {
      Object.keys(vars).forEach(function (key) {
        value = value.split("{" + key + "}").join(String(vars[key]));
      });
    }
    return value;
  }

  function translateMessage(message) {
    var text = String(message == null ? "" : message);
    var exact = t(text);
    if (exact !== text) {
      return exact;
    }
    var lang = activeLanguageId();
    var prefixes = [
      ["Nenhuma API retornou um pacote válido.", {
        en: "No API returned a valid package.",
        es: "Ninguna API devolvió un paquete válido.",
        ru: "Ни один API не вернул допустимый пакет."
      }],
      ["Não foi possível abrir o pacote zip.", {
        en: "Could not open the zip package.",
        es: "No se pudo abrir el paquete zip.",
        ru: "Не удалось открыть zip-пакет."
      }],
      ["Já existe uma operação em andamento para este jogo.", {
        en: "There is already an operation running for this game.",
        es: "Ya hay una operación en curso para este juego.",
        ru: "Для этой игры уже выполняется операция."
      }]
    ];
    for (var p = 0; p < prefixes.length; p += 1) {
      if (text.indexOf(prefixes[p][0]) === 0 && lang !== "pt-BR") {
        return prefixes[p][1][lang] + text.slice(prefixes[p][0].length);
      }
    }
    var replacements = [
      [/^(\d+) jogos adicionados\. Integração: (.+)\.$/, "{count} games added. Integration: {integration}.", "{count} juegos añadidos. Integración: {integration}.", "{count} игр добавлено. Интеграция: {integration}."],
      [/^Manifests: (\d+)\. DLCs: (\d+)\.$/, "Manifests: {manifests}. DLCs: {dlcs}.", "Manifests: {manifests}. DLCs: {dlcs}.", "Манифесты: {manifests}. DLC: {dlcs}."],
      [/^Resultados para (.+)$/, "Results for {name}", "Resultados para {name}", "Результаты для {name}"],
      [/^Mostrar mais (\d+) de (\d+)$/, "Show {count} more of {total}", "Mostrar {count} más de {total}", "Показать еще {count} из {total}"],
      [/^(\d+) jogo\(s\) carregado\(s\)$/, "{count} game(s) loaded", "{count} juego(s) cargado(s)", "{count} игр загружено"],
      [/^(\d+) item\(ns\) encontrados\.$/, "{count} item(s) found.", "{count} elemento(s) encontrados.", "Найдено элементов: {count}."]
    ];
    for (var i = 0; i < replacements.length; i += 1) {
      var match = text.match(replacements[i][0]);
      if (!match) {
        continue;
      }
      var template = lang === "en" ? replacements[i][1] : lang === "es" ? replacements[i][2] : lang === "ru" ? replacements[i][3] : text;
      return template
        .replace("{count}", match[1] || "")
        .replace("{integration}", match[2] || "")
        .replace("{manifests}", match[1] || "")
        .replace("{dlcs}", match[2] || "")
        .replace("{name}", match[1] || "")
        .replace("{total}", match[2] || "");
    }
    return text;
  }

  function localizeDom(root) {
    if (!root || !document.createTreeWalker) {
      return;
    }
    var walker = document.createTreeWalker(root, window.NodeFilter ? window.NodeFilter.SHOW_TEXT : 4, null);
    var nodes = [];
    while (walker.nextNode()) {
      nodes.push(walker.currentNode);
    }
    for (var i = 0; i < nodes.length; i += 1) {
      var raw = nodes[i].nodeValue || "";
      var trimmed = raw.trim();
      if (!trimmed) {
        continue;
      }
      var translated = translateMessage(trimmed);
      if (translated !== trimmed) {
        nodes[i].nodeValue = raw.replace(trimmed, translated);
      }
    }
    var attrs = ["title", "placeholder", "aria-label"];
    var elements = root.querySelectorAll ? root.querySelectorAll("[title],[placeholder],[aria-label]") : [];
    for (var e = 0; e < elements.length; e += 1) {
      for (var a = 0; a < attrs.length; a += 1) {
        var attr = attrs[a];
        var value = elements[e].getAttribute(attr);
        if (value) {
          elements[e].setAttribute(attr, translateMessage(value));
        }
      }
    }
  }

  function log(message) {
    try {
      console.log("[SkyTools]", message);
    } catch (_) {}
  }

  function parseResponse(response) {
    if (typeof response === "string") {
      try {
        return JSON.parse(response);
      } catch (_) {
        return { success: false, error: response };
      }
    }
    return response || {};
  }

  function methodTimeoutMs(label) {
    var name = String(label || "");
    var timeouts = {
      SkyToolsAddGame: 190000,
      SkyToolsApplyFix: 910000,
      SkyToolsBackupRestore: 130000,
      SkyToolsBackupExport: 70000,
      SkyToolsInstalled: 70000,
      SkyToolsSteamInstalled: 70000,
      SkyToolsFixCatalog: 70000,
      SkyToolsFixSources: 70000,
      SkyToolsOnlineFix: 70000,
      SkyToolsDenuvoFix: 70000,
      SkyToolsRemoveGame: 70000,
      SkyToolsSetUpdateLock: 70000,
      SkyToolsSaveGameSettings: 70000,
      SkyToolsRemoveFix: 70000,
      SkyToolsRepair: 100000,
      SkyToolsIntegration: 70000
    };
    return timeouts[name] || 35000;
  }

  function withTimeout(promise, label) {
    var timeoutMs = methodTimeoutMs(label);
    return new Promise(function (resolve, reject) {
      var settled = false;
      var timer = setTimeout(function () {
        if (!settled) {
          settled = true;
          reject(new Error((label || "Chamada") + " demorou demais para responder."));
        }
      }, timeoutMs);
      promise.then(function (value) {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          resolve(value);
        }
      }, function (error) {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          reject(error);
        }
      });
    });
  }

  function wrapPayload(payload) {
    var value = payload || {};
    if (typeof value === "object") {
      return { payload: JSON.stringify(value) };
    }
    return { payload: String(value) };
  }

  function isBridgeSignatureError(error) {
    var message = String(error && error.message ? error.message : error || "");
    return /startswith is not a function|method(?:name)?[^a-z]*(?:must|should)[^a-z]*be[^a-z]*string|expected[^a-z]*string/i.test(message);
  }

  function callLegacy(method, payload) {
    return withTimeout(
      Promise.resolve(Millennium.callServerMethod(PLUGIN_ID, method, wrapPayload(payload))).then(parseResponse),
      method
    );
  }

  function callDirect(method, payload) {
    if (typeof Millennium === "undefined" || typeof Millennium.callServerMethod !== "function") {
      return Promise.reject(new Error("Millennium bridge indisponível"));
    }
    if (state.bridgeCallMode === "legacy") {
      return callLegacy(method, payload);
    }
    try {
      return withTimeout(
        Promise.resolve(Millennium.callServerMethod(method, wrapPayload(payload))).then(parseResponse),
        method
      ).then(function (result) {
        state.bridgeCallMode = "direct";
        return result;
      }, function (error) {
        if (state.bridgeCallMode !== "direct" && isBridgeSignatureError(error)) {
          state.bridgeCallMode = "legacy";
          return callLegacy(method, payload);
        }
        throw error;
      });
    } catch (error) {
      if (state.bridgeCallMode !== "direct" && isBridgeSignatureError(error)) {
        state.bridgeCallMode = "legacy";
        return callLegacy(method, payload);
      }
      return Promise.reject(error);
    }
  }

  function call(method, payload) {
    var execute = function () {
      return callDirect(method, payload);
    };
    var queued = state.bridgeCallTail.then(execute, execute);
    state.bridgeCallTail = queued.then(function () {}, function () {});
    return queued;
  }

  function callJson(method, payload) {
    return call(method, payload || {});
  }

  function callArgs(method, args) {
    args = Array.isArray(args) ? args : [];
    if (typeof Millennium === "undefined" || typeof Millennium.callServerMethod !== "function") {
      return Promise.reject(new Error("Millennium bridge indisponível"));
    }
    return call(method, { args: args });
  }

  function apiFormArgs(api) {
    api = api || {};
    return [
      String(api.id || ""),
      String(api.name || ""),
      String(api.urlTemplate || ""),
      String(api.apiKey || ""),
      api.enabled !== false,
      api.useProxy === true,
      String(api.proxyUrlTemplate || ""),
      Number(api.successCode) || 200,
      Number(api.unavailableCode) || 404
    ];
  }

  function appIdFromUrl() {
    var match = String(location.href).match(/\/app\/(\d+)/i);
    return match ? match[1] : "";
  }

  function appNameFromPage() {
    var selectors = [".apphub_AppName", ".game_title_area .title", "#appHubAppName", "h1"];
    for (var i = 0; i < selectors.length; i += 1) {
      var node = document.querySelector(selectors[i]);
      if (node && node.textContent.trim()) {
        return node.textContent.trim();
      }
    }
    var meta = document.querySelector('meta[property="og:title"], meta[name="twitter:title"]');
    if (meta && meta.getAttribute("content")) {
      return meta.getAttribute("content").replace(/\s+on Steam\s*$/i, "").trim();
    }
    return document.title.replace(/\s+on Steam\s*$/i, "").trim();
  }

  function isPlaceholderName(name, appid) {
    var value = String(name || "").trim();
    var id = String(appid || "").trim();
    if (!value) return true;
    if (id && value === id) return true;
    if (id && value.toLowerCase() === ("appid " + id).toLowerCase()) return true;
    return /^AppID\s+\d+$/i.test(value);
  }

  function currentPayload() {
    var appid = appIdFromUrl();
    var name = appid ? (appNameFromPage() || (state.appid === appid ? state.appName : "") || state.nameCache[String(appid)] || "") : "";
    if (isPlaceholderName(name, appid)) {
      name = state.nameCache[String(appid)] || "";
    }
    return {
      appid: appid,
      name: name
    };
  }

  function normalizeAppIdInput(value) {
    return String(value || "").replace(/\D/g, "");
  }

  function payloadForAppId(appid) {
    appid = normalizeAppIdInput(appid);
    var pageAppId = appIdFromUrl();
    var name = pageAppId === appid ? appNameFromPage() : "";
    name = name || state.nameCache[appid] || "";
    if (isPlaceholderName(name, appid)) {
      name = state.nameCache[appid] || "";
    }
    return { appid: appid, name: name };
  }

  function syncAddAppIdFromPage() {
    var pageAppId = appIdFromUrl();
    var changed = false;
    if (pageAppId && pageAppId !== state.lastPageAppId) {
      state.addAppIdInput = pageAppId;
      changed = true;
    }
    state.lastPageAppId = pageAppId;
    return changed;
  }

  function normalizeData(result) {
    if (!result) {
      return null;
    }
    return result.data !== undefined ? result.data : result;
  }

  function isPendingResult(result) {
    var data = normalizeData(result) || {};
    return !!(result && result.success !== false && data.pending === true);
  }

  function shouldRunStartupPreload() {
    try {
      var last = Number(localStorage.getItem(PRELOAD_STORAGE_KEY) || 0) || 0;
      var now = Date.now();
      if (last && now - last < 180000) {
        return false;
      }
      localStorage.setItem(PRELOAD_STORAGE_KEY, String(now));
    } catch (_) {}
    return true;
  }

  function readInstalledSnapshot() {
    try {
      var parsed = JSON.parse(localStorage.getItem(INSTALLED_STORAGE_KEY) || "null");
      if (!parsed || !Array.isArray(parsed.games)) {
        return null;
      }
      var savedAt = Number(parsed.savedAt || 0) || 0;
      if (savedAt && Date.now() - savedAt > INSTALLED_SNAPSHOT_TTL) {
        return null;
      }
      return parsed;
    } catch (_) {
      return null;
    }
  }

  function writeInstalledSnapshot(result) {
    try {
      var games = gameArray(result);
      var map = {};
      for (var i = 0; i < games.length; i += 1) {
        var appid = String(gameAppId(games[i]) || "");
        if (appid) {
          map[appid] = true;
        }
      }
      localStorage.setItem(INSTALLED_STORAGE_KEY, JSON.stringify({
        savedAt: Date.now(),
        games: games,
        map: map
      }));
    } catch (_) {}
  }

  function readFixCatalogSnapshot() {
    try {
      var parsed = JSON.parse(localStorage.getItem(FIX_CATALOG_STORAGE_KEY) || "null");
      if (!parsed || !parsed.result || !Number(parsed.savedAt)) {
        return null;
      }
      if (Date.now() - Number(parsed.savedAt) >= FIX_CATALOG_SNAPSHOT_TTL) {
        return null;
      }
      return parsed.result;
    } catch (_) {
      return null;
    }
  }

  function writeFixCatalogSnapshot(result) {
    try {
      localStorage.setItem(FIX_CATALOG_STORAGE_KEY, JSON.stringify({
        savedAt: Date.now(),
        result: result
      }));
    } catch (_) {}
  }

  function markInstalledRefreshOnStart() {
    try {
      localStorage.setItem(REFRESH_INSTALLED_ON_START_KEY, "1");
    } catch (_) {}
  }

  function consumeInstalledRefreshOnStart() {
    try {
      var requested = localStorage.getItem(REFRESH_INSTALLED_ON_START_KEY) === "1";
      if (requested) {
        localStorage.removeItem(REFRESH_INSTALLED_ON_START_KEY);
      }
      return requested;
    } catch (_) {
      return false;
    }
  }

  function hydrateInstalledSnapshot() {
    var snapshot = readInstalledSnapshot();
    if (!snapshot) {
      return;
    }
    state.installed = snapshot.games;
    state.installedMap = snapshot.map || {};
    state.installedLoadedAt = Number(snapshot.savedAt || 0) || Date.now();
  }

  function upsertInstalledFromAddResult(result, payload) {
    var data = normalizeData(result) || {};
    var appid = String(data.appId || data.appid || payload.appid || "");
    if (!appid) {
      return;
    }
    var hadCompleteList = !!state.installed;
    var installed = gameArray(state.installed).slice();
    if (!hadCompleteList) {
      var snapshot = readInstalledSnapshot();
      if (snapshot && Array.isArray(snapshot.games)) {
        installed = snapshot.games.slice();
        hadCompleteList = true;
      }
    }
    state.installed = installed;
    state.installedMap[appid] = true;
    rememberGameName(appid, data.gameName || payload.name || "");
    var found = false;
    for (var i = 0; i < state.installed.length; i += 1) {
      if (String(gameAppId(state.installed[i])) === appid) {
        state.installed[i] = Object.assign({}, state.installed[i], {
          appId: Number(appid) || appid,
          appid: Number(appid) || appid,
          gameName: data.gameName || payload.name || state.installed[i].gameName || "",
          name: data.gameName || payload.name || state.installed[i].name || "",
          fullPath: data.scriptPath || state.installed[i].fullPath || "",
          dlcCount: data.dlcCount || state.installed[i].dlcCount || 0,
          isDisabled: false
        });
        found = true;
        break;
      }
    }
    if (!found) {
      state.installed.push({
        appId: Number(appid) || appid,
        appid: Number(appid) || appid,
        gameName: data.gameName || payload.name || "",
        name: data.gameName || payload.name || "",
        fullPath: data.scriptPath || "",
        dlcCount: data.dlcCount || 0,
        isDisabled: false
      });
    }
    if (hadCompleteList) {
      writeInstalledSnapshot(state.installed);
    }
  }

  function readStoredTheme() {
    try {
      for (var i = 0; i < THEME_STORAGE_KEYS.length; i += 1) {
        var stored = String(localStorage.getItem(THEME_STORAGE_KEYS[i]) || "").trim();
        if (stored) {
          return stored;
        }
      }
      return DEFAULT_THEME;
    } catch (_) {
      return DEFAULT_THEME;
    }
  }

  function writeStoredTheme(themeId) {
    try {
      var value = themeId || DEFAULT_THEME;
      for (var i = 0; i < THEME_STORAGE_KEYS.length; i += 1) {
        localStorage.setItem(THEME_STORAGE_KEYS[i], value);
      }
    } catch (_) {
      // O CSS base mantém o tema oficial mesmo quando o storage da WebView falha.
    }
  }

  function readStoredLanguage() {
    try {
      return normalizeLanguageId(localStorage.getItem(LANGUAGE_STORAGE_KEY) || DEFAULT_LANGUAGE);
    } catch (_) {
      return DEFAULT_LANGUAGE;
    }
  }

  function writeStoredLanguage(languageId) {
    try {
      localStorage.setItem(LANGUAGE_STORAGE_KEY, normalizeLanguageId(languageId));
    } catch (_) {
      // Local storage can be unavailable in Steam WebView; backend persistence remains authoritative.
    }
  }

  function readStoredFabCollapsed() {
    try {
      return localStorage.getItem(FAB_COLLAPSED_STORAGE_KEY) === "1";
    } catch (_) {
      return false;
    }
  }

  function writeStoredFabCollapsed(value) {
    try {
      localStorage.setItem(FAB_COLLAPSED_STORAGE_KEY, value ? "1" : "0");
    } catch (_) {
      // O botão continua utilizável mesmo se a WebView bloquear persistência.
    }
  }

  function syncLanguageFromStatus(result) {
    var data = normalizeData(result) || {};
    var saved = data.selectedLanguageId || data.selectedLanguage || data.language || data.Language;
    if (saved) {
      state.languageMode = normalizeLanguageId(saved);
      writeStoredLanguage(state.languageMode);
    }
  }

  function saveThemePreference(themeId) {
    themeId = themeId || DEFAULT_THEME;
    writeStoredTheme(themeId);
    function localThemeSavedResult(error) {
      return {
        success: true,
        data: {
          themeId: themeId,
          selectedThemeId: themeId,
          localOnly: true,
          warning: error ? String(error) : ""
        }
      };
    }

    function confirmSaved() {
      return call("SkyToolsStatus", {}).then(function (status) {
        var data = normalizeData(status) || {};
        var savedTheme = String(data.selectedThemeId || data.SelectedThemeId || "").trim();
        if (savedTheme === themeId) {
          state.status = status;
          return { success: true };
        }
        return { success: false, error: "O backend não confirmou o tema salvo." };
      }, function (error) {
        return localThemeSavedResult(error);
      });
    }

    return call("SkyToolsSaveApiSettings", { selectedThemeId: themeId, themeId: themeId }).then(function (result) {
      if (result && result.success === false) {
        return result;
      }
      return confirmSaved();
    }).then(function (result) {
      if (!result || result.success !== false) {
        return result;
      }
      return call("SkyToolsSaveTheme", { themeId: themeId, selectedThemeId: themeId }).then(function (fallbackResult) {
        if (fallbackResult && fallbackResult.success === false) {
          return fallbackResult;
        }
        return confirmSaved();
      });
    }).catch(function (error) {
      return localThemeSavedResult(error);
    });
  }

  function safeThemeFile(file) {
    var value = String(file || "").trim();
    if (!/^[a-z0-9][a-z0-9._-]*\.css$/i.test(value)) {
      return "official-orange.css";
    }
    return value;
  }

  function themeArray(result) {
    var data = normalizeData(result) || {};
    var source = Array.isArray(data.themes) ? data.themes : [];
    var themes = [];
    var seen = {};

    function add(theme) {
      var id = String(theme && theme.id || "").trim();
      var file = safeThemeFile(theme && theme.file || "");
      var name = String(theme && theme.name || "").trim();
      if (!id) {
        id = file.replace(/\.css$/i, "");
      }
      if (!id || seen[id]) {
        return;
      }
      seen[id] = true;
      themes.push({ id: id, name: name || id, file: file });
    }

    for (var builtInIndex = 0; builtInIndex < BUILT_IN_THEMES.length; builtInIndex += 1) {
      add(BUILT_IN_THEMES[builtInIndex]);
    }
    for (var i = 0; i < source.length; i += 1) {
      add(source[i]);
    }
    return themes;
  }

  function themeById(themeId) {
    var themes = state.themes && state.themes.length ? state.themes : themeArray(state.status);
    var requested = String(themeId || "").trim();
    for (var i = 0; i < themes.length; i += 1) {
      if (String(themes[i].id) === requested) {
        return themes[i];
      }
    }
    if (!state.status && requested && requested !== DEFAULT_THEME && /^[a-z0-9][a-z0-9._-]*$/i.test(requested)) {
      return { id: requested, name: requested, file: requested + ".css" };
    }
    return themes[0] || { id: DEFAULT_THEME, name: "Oficial laranja", file: "official-orange.css" };
  }

  function hasTheme(themeId) {
    var themes = state.themes && state.themes.length ? state.themes : themeArray(state.status);
    for (var i = 0; i < themes.length; i += 1) {
      if (String(themes[i].id) === String(themeId || "")) {
        return true;
      }
    }
    return false;
  }

  function themeUrlCandidates(file) {
    var encoded = encodeURIComponent(safeThemeFile(file));
    var suffix = "?v=" + encodeURIComponent(SKYTOOLS_UI_VERSION);
    return [
      "/webkit/SkyTools/themes/" + encoded + suffix,
      "webkit/SkyTools/themes/" + encoded + suffix,
      "SkyTools/themes/" + encoded + suffix,
      "themes/" + encoded + suffix
    ];
  }

  function isThemeCss(css) {
    var text = String(css || "");
    return text.indexOf("--skytools-") >= 0;
  }

  function themeScopeSelector(themeId) {
    return [
      'html.skytools-theme-scope[data-skytools-theme="' + String(themeId || DEFAULT_THEME) + '"]',
      'html.skytools-theme-scope[data-skytools-theme="' + String(themeId || DEFAULT_THEME) + '"] body',
      '.skytools-panel',
      '.skytools-fab-shell',
      '.skytools-fab',
      '.skytools-fab-toggle',
      '.skytools-game-button',
      '.skytools-toast'
    ].join(", ");
  }

  function scopedThemeCss(theme, declarations) {
    return themeScopeSelector(theme.id) + " {\n" + declarations.join("\n") + "\n}";
  }

  function themeVarMapFromCss(css) {
    var matches = String(css || "").match(/--skytools-[a-z0-9-]+\s*:\s*[^;]+;/gi) || [];
    var vars = {};
    for (var i = 0; i < matches.length; i += 1) {
      var declaration = matches[i].replace(/\s*!important\s*;/i, ";").replace(/;$/, "");
      var colon = declaration.indexOf(":");
      if (colon <= 0) {
        continue;
      }
      var name = declaration.slice(0, colon).trim();
      var value = declaration.slice(colon + 1).trim();
      if (name.indexOf("--skytools-") === 0 && value) {
        vars[name] = value;
      }
    }
    return vars;
  }

  function builtInThemeVarMap(themeId) {
    var values = BUILT_IN_THEME_VARS[String(themeId || "")];
    var vars = {};
    if (!values) {
      return vars;
    }
    Object.keys(values).forEach(function (key) {
      vars["--skytools-" + key] = values[key];
    });
    return vars;
  }

  function applyThemeVars(vars) {
    vars = vars || state.themeVars || builtInThemeVarMap(state.themeId);
    if (!vars || !Object.keys(vars).length) {
      return;
    }
    state.themeVars = vars;
    var nodes = [document.documentElement];
    if (document.body) {
      nodes.push(document.body);
    }
    var scopedNodes = document.querySelectorAll(".skytools-panel,.skytools-fab-shell,.skytools-fab,.skytools-fab-toggle,.skytools-game-button,.skytools-toast");
    for (var i = 0; i < scopedNodes.length; i += 1) {
      nodes.push(scopedNodes[i]);
    }
    Object.keys(vars).forEach(function (name) {
      for (var index = 0; index < nodes.length; index += 1) {
        if (nodes[index] && nodes[index].style && nodes[index].style.setProperty) {
          if (nodes[index].style.getPropertyValue(name) !== vars[name] || nodes[index].style.getPropertyPriority(name) !== "important") {
            nodes[index].style.setProperty(name, vars[name], "important");
          }
        }
      }
    });
  }

  function builtInThemeCss(theme) {
    var values = BUILT_IN_THEME_VARS[String(theme.id || "")];
    if (!values) {
      return "";
    }
    var declarations = [];
    Object.keys(values).forEach(function (key) {
      declarations.push("  --skytools-" + key + ": " + values[key] + " !important;");
    });
    return scopedThemeCss(theme, declarations);
  }

  function normalizeThemeCss(theme, css) {
    var matches = String(css || "").match(/--skytools-[a-z0-9-]+\s*:\s*[^;]+;/gi) || [];
    var declarations = [];
    var seen = {};
    for (var i = 0; i < matches.length; i += 1) {
      var declaration = matches[i].replace(/\s*!important\s*;/i, ";").trim();
      var name = declaration.split(":")[0].trim().toLowerCase();
      if (!name || seen[name]) {
        continue;
      }
      seen[name] = true;
      declarations.push("  " + declaration.replace(/;$/, " !important;"));
    }
    return declarations.length ? scopedThemeCss(theme, declarations) : "";
  }

  function fetchThemeCss(theme) {
    if (typeof fetch !== "function") {
      return Promise.reject(new Error("fetch indisponível"));
    }
    var urls = themeUrlCandidates(theme.file);
    var index = 0;

    function next() {
      if (index >= urls.length) {
        return Promise.reject(new Error("Tema não encontrado no webkit"));
      }
      var url = urls[index];
      index += 1;
      return fetch(url, { cache: "no-store" }).then(function (response) {
        if (!response || !response.ok) {
          throw new Error("HTTP " + (response && response.status || 0));
        }
        return response.text();
      }).then(function (css) {
        if (!isThemeCss(css)) {
          throw new Error("CSS de tema inválido");
        }
        return css;
      }).catch(function () {
        return next();
      });
    }

    return next();
  }

  function backendThemeCss(theme) {
    return call("SkyToolsTheme", { id: theme.id, file: theme.file }).then(function (result) {
      var data = normalizeData(result) || {};
      if (result && result.success === false || !isThemeCss(data.css)) {
        throw new Error(result && result.error || "Tema não retornou CSS válido");
      }
      return data.css;
    });
  }

  function loadThemeCss(theme) {
    var builtIn = builtInThemeCss(theme);
    if (builtIn) {
      return Promise.resolve(builtIn);
    }
    return fetchThemeCss(theme).catch(function () {
      return backendThemeCss(theme);
    }).then(function (css) {
      var normalized = normalizeThemeCss(theme, css);
      if (!normalized) {
        throw new Error("CSS de tema sem variáveis SkyTools");
      }
      return normalized;
    });
  }

  function ensureThemeStyle() {
    var oldLink = document.getElementById("skytools-theme-link");
    if (oldLink) {
      oldLink.remove();
    }

    var style = document.getElementById("skytools-theme-style");
    if (!style) {
      style = document.createElement("style");
      style.id = "skytools-theme-style";
      style.type = "text/css";
    }
    if (style.parentNode !== document.head) {
      document.head.appendChild(style);
    }
    return style;
  }

  function injectThemeCss(theme, css) {
    var style = ensureThemeStyle();
    style.dataset.themeId = theme.id || DEFAULT_THEME;
    style.dataset.themeFile = safeThemeFile(theme.file);
    style.textContent = String(css || "");
    state.themeCss = String(css || "");
    state.themeAppliedId = theme.id || DEFAULT_THEME;
    state.themeVars = themeVarMapFromCss(css);
    if (!Object.keys(state.themeVars).length) {
      state.themeVars = builtInThemeVarMap(state.themeAppliedId);
    }
    document.documentElement.setAttribute("data-skytools-theme", theme.id || DEFAULT_THEME);
    applyThemeVars(state.themeVars);
  }

  function ensureAppliedTheme() {
    if (!document.documentElement.classList.contains("skytools-theme-scope")) {
      document.documentElement.classList.add("skytools-theme-scope");
    }
    if (document.documentElement.getAttribute("data-skytools-theme") !== (state.themeId || DEFAULT_THEME)) {
      document.documentElement.setAttribute("data-skytools-theme", state.themeId || DEFAULT_THEME);
    }
    applyThemeVars();
    var style = document.getElementById("skytools-theme-style");
    if (state.themeCss && (!style || style.textContent !== state.themeCss || style.dataset.themeId !== state.themeAppliedId)) {
      var theme = themeById(state.themeAppliedId || state.themeId);
      injectThemeCss(theme, state.themeCss);
      return;
    }
    if (style && style.parentNode !== document.head) {
      document.head.appendChild(style);
    }
  }

  function fallbackToDefaultTheme() {
    if (!state.status || state.themeId === DEFAULT_THEME) {
      return;
    }
    state.themeId = DEFAULT_THEME;
    writeStoredTheme(DEFAULT_THEME);
    applyTheme(DEFAULT_THEME);
    renderPanelBody();
  }

  function applyTheme(themeId) {
    var theme = themeById(themeId || state.themeId);
    var requestId = state.themeRequestId + 1;
    state.themeRequestId = requestId;
    state.themeId = theme.id || DEFAULT_THEME;
    document.documentElement.classList.add("skytools-theme-scope");
    document.documentElement.setAttribute("data-skytools-theme", state.themeId);
    applyThemeVars(builtInThemeVarMap(state.themeId));

    return loadThemeCss(theme).then(function (css) {
      if (requestId !== state.themeRequestId) {
        return { success: true };
      }
      injectThemeCss(theme, css);
      ensureAppliedTheme();
      return { success: true, data: { id: theme.id, file: theme.file } };
    }, function (error) {
      if (requestId === state.themeRequestId) {
        fallbackToDefaultTheme();
      }
      return { success: false, error: String(error) };
    });
  }

  function syncThemesFromStatus(result) {
    var data = normalizeData(result) || {};
    var backendThemeId = String(data.selectedThemeId || data.SelectedThemeId || "").trim();
    var storedThemeId = String(readStoredTheme() || "").trim();
    state.themes = themeArray(result);

    if (backendThemeId && hasTheme(backendThemeId)) {
      state.themeId = backendThemeId;
      writeStoredTheme(backendThemeId);
    } else if (storedThemeId && hasTheme(storedThemeId)) {
      state.themeId = storedThemeId;
    }

    if (!hasTheme(state.themeId)) {
      state.themeId = DEFAULT_THEME;
      writeStoredTheme(DEFAULT_THEME);
    }
    applyTheme(state.themeId);
  }

  function gameArray(result) {
    var data = normalizeData(result);
    if (Array.isArray(data)) {
      return data;
    }
    if (data && Array.isArray(data.games)) {
      return data.games;
    }
    return [];
  }

  function applyInstalledResult(result) {
    var games = gameArray(result);
    var data = normalizeData(result) || {};
    var previous = gameArray(state.installed);
    if (data.scanFailed === true && games.length === 0 && previous.length > 0) {
      log("SkyToolsInstalled: atualização falhou; mantendo a última biblioteca válida.");
      return state.installed;
    }
    state.installed = games;
    updateNameCacheFromInstalled(games);
    writeInstalledSnapshot(games);
    return games;
  }

  function removeInstalledGameFromState(appid) {
    var wanted = String(appid || "");
    var games = gameArray(state.installed).filter(function (game) {
      return String(gameAppId(game) || "") !== wanted;
    });
    state.installed = games;
    updateNameCacheFromInstalled(games);
    writeInstalledSnapshot(games);
    updateGameButton();
    return games;
  }

  function gameAppId(game) {
    return game.appId || game.appid || "";
  }

  function rememberGameName(appid, name) {
    if (!appid || !name || /^App(ID)?\s+\d+/i.test(name)) {
      return;
    }
    state.nameCache[String(appid)] = name;
  }

  function displayGameName(game) {
    var appid = gameAppId(game);
    var name = game.gameName || game.name || state.nameCache[String(appid)] || "";
    return name || ("AppID " + appid);
  }

  function apiId(api) {
    return canonicalApiId((api && (api.id || api.Id)) || "");
  }

  function canonicalApiId(id) {
    var value = String(id || "").trim();
    if (value.toLowerCase() === "sushi") {
      return "ryzen";
    }
    return value;
  }

  function defaultApiOrder() {
    return ["skyapi", "morrenus", "ryzen"];
  }

  function readStoredApiOrder() {
    try {
      var parsed = JSON.parse(localStorage.getItem(API_ORDER_STORAGE_KEY) || "[]");
      return Array.isArray(parsed) && parsed.length ? parsed : null;
    } catch (_) {
      return null;
    }
  }

  function writeStoredApiOrder(order) {
    if (!Array.isArray(order) || !order.length) {
      return;
    }
    try {
      localStorage.setItem(API_ORDER_STORAGE_KEY, JSON.stringify(order));
    } catch (_) {
      // Steam WebView storage can be unavailable in rare contexts; backend persistence remains authoritative.
    }
  }

  function orderApis(apis, order) {
    var list = (apis || []).slice();
    var preferredOrder = Array.isArray(order) && order.length ? order : defaultApiOrder();
    var rank = {};
    preferredOrder.forEach(function (id, index) {
      rank[canonicalApiId(id).toLowerCase()] = index;
    });
    list.sort(function (left, right) {
      var leftRank = rank[apiId(left).toLowerCase()];
      var rightRank = rank[apiId(right).toLowerCase()];
      if (leftRank == null) leftRank = 9999;
      if (rightRank == null) rightRank = 9999;
      if (leftRank !== rightRank) return leftRank - rightRank;
      return 0;
    });
    return list;
  }

  function reorderApiOrder(dragId, targetId, afterTarget) {
    dragId = String(dragId || "");
    targetId = String(targetId || "");
    if (!dragId || !targetId || dragId === targetId) {
      return false;
    }
    var order = (state.apiOrder || []).slice();
    var from = order.indexOf(dragId);
    var to = order.indexOf(targetId);
    if (from < 0 || to < 0) {
      return false;
    }
    order.splice(from, 1);
    if (from < to) {
      to -= 1;
    }
    if (afterTarget) {
      to += 1;
    }
    order.splice(to, 0, dragId);
    state.apiOrder = order;
    return true;
  }

  function apiListFromData(value) {
    return Array.isArray(value) ? value : [];
  }

  function isValidApi(api) {
    if (!api || typeof api !== "object") {
      return false;
    }
    var id = String(api.id || api.Id || "").trim();
    var name = String(api.name || api.Name || "").trim();
    var url = String(api.urlTemplate || api.UrlTemplate || "").trim();
    return !!(id && name && url && url.indexOf("<appid>") >= 0);
  }

  function collectApiOrderFromDom(panel) {
    var rows = panel ? panel.querySelectorAll(".skytools-api-draggable[data-api-id]") : [];
    var order = [];
    for (var i = 0; i < rows.length; i += 1) {
      var id = canonicalApiId(rows[i].getAttribute("data-api-id") || "");
      if (id) {
        order.push(id);
      }
    }
    return order;
  }

  function updateNameCacheFromInstalled(result) {
    var list = gameArray(result);
    var map = {};
    for (var i = 0; i < list.length; i += 1) {
      var appid = String(gameAppId(list[i]) || "");
      if (appid) {
        map[appid] = true;
      }
      rememberGameName(appid, list[i].gameName || list[i].name || "");
    }
    state.installedMap = map;
    state.installedLoadedAt = Date.now();
    if (state.status) {
      var statusData = normalizeData(state.status);
      if (statusData) {
        statusData.installedCount = list.length;
      }
    }
    updateGameButton();
  }

  function isCurrentAppAdded() {
    var appid = String(appIdFromUrl() || state.appid || "");
    return !!(appid && state.installedMap[appid]);
  }

  function friendlyError(result) {
    if (!result) {
      return t("A ação falhou.");
    }
    return translateMessage(result.error || result.message || "A ação falhou.");
  }

  function setActivity(kind, title, detail) {
    state.activityKind = kind || "idle";
    state.activityTitle = title ? translateMessage(title) : "SkyTools";
    state.activityDetail = detail ? translateMessage(detail) : "";
    updateActivity();
  }

  function showToast(title, message, kind) {
    if (document.querySelector(".skytools-panel")) {
      return;
    }

    var previous = document.querySelector(".skytools-toast");
    if (previous) {
      previous.remove();
    }

    var toast = document.createElement("div");
    toast.className = "skytools-toast skytools-toast-" + (kind || "info");
    toast.innerHTML =
      '<div class="skytools-toast-icon">' + icon(kind === "error" ? "error" : kind === "success" ? "check" : "status") + "</div>" +
      '<div><strong></strong><span></span></div>';
    toast.querySelector("strong").textContent = translateMessage(title);
    toast.querySelector("span").textContent = translateMessage(message || "");
    document.body.appendChild(toast);
    window.setTimeout(function () {
      if (toast.parentNode) {
        toast.remove();
      }
    }, 5200);
  }

  function setBusy(title, detail) {
    state.busy = true;
    setActivity("busy", title || "Processando", detail || "Executando em segundo plano...");
    updateBusyState();
  }

  function clearBusy(title, detail, kind) {
    state.busy = false;
    if (title !== false) {
      setActivity(kind || "idle", title || "Pronto", detail || "Aguardando uma ação.");
    }
    updateBusyState();
    flushPendingTab();
  }

  function buttonTarget() {
    var selectors = [
      ".game_purchase_action",
      ".game_area_purchase_game",
      ".game_area_purchase",
      "#game_area_purchase",
      ".rightcol"
    ];
    for (var i = 0; i < selectors.length; i += 1) {
      var node = document.querySelector(selectors[i]);
      if (node) {
        return node;
      }
    }
    return null;
  }

  function removeGameButton() {
    var old = document.querySelector(".skytools-game-button");
    if (old) {
      old.remove();
    }
  }

  function removeGameIndicators() {
    var old = document.querySelector(".skytools-game-indicators");
    if (old) {
      old.remove();
    }
  }

  function communityHubButton(appid) {
    var selectors = [
      ".apphub_OtherSiteInfo a[href*='steamcommunity.com/app/" + appid + "']",
      ".apphub_OtherSiteInfo a",
      "a[href*='steamcommunity.com/app/" + appid + "']"
    ];
    for (var i = 0; i < selectors.length; i += 1) {
      var candidate = document.querySelector(selectors[i]);
      if (candidate) {
        return candidate;
      }
    }
    return null;
  }

  function gameNoticeText() {
    var selectors = [
      ".DRM_notice",
      ".game_area_details_specs",
      ".game_area_details_specs_ctn",
      ".game_details"
    ];
    var nodes = document.querySelectorAll(selectors.join(","));
    var parts = [];
    for (var i = 0; i < nodes.length; i += 1) {
      var text = String(nodes[i].textContent || "").trim();
      if (text) {
        parts.push(text);
      }
    }
    return parts.join(" ").replace(/\s+/g, " ").toLowerCase();
  }

  function storePageSignals() {
    var text = gameNoticeText();
    return {
      denuvo: /(^|[^a-z0-9])denuvo([^a-z0-9]|$)/i.test(text),
      ea: /(^|[^a-z0-9])ea(?:\s+(?:app|online))?([^a-z0-9]|$)/i.test(text),
      ubisoft: /(^|[^a-z0-9])ubisoft(?:\s+account)?([^a-z0-9]|$)/i.test(text),
      rockstar: /(^|[^a-z0-9])rockstar([^a-z0-9]|$)/i.test(text)
    };
  }

  function gameIndicator(iconName, label, title, kind) {
    return {
      iconName: iconName,
      label: label,
      title: title,
      kind: kind
    };
  }

  function updateGameIndicators() {
    var appid = appIdFromUrl();
    if (!appid) {
      removeGameIndicators();
      state.indicatorCatalogAppId = "";
      return;
    }

    var communityButton = communityHubButton(appid);
    if (!communityButton || !communityButton.parentNode) {
      return;
    }

    var indicators = [];
    var fixKinds = state.fixKindsMap[String(appid)] || {};
    var signals = storePageSignals();
    if (fixKinds.online) {
      indicators.push(gameIndicator("online", t("Correção Online"), t("Correção online disponível"), "online"));
    }
    if (fixKinds.generic) {
      indicators.push(gameIndicator("fixes", t("Correção Genérica"), t("Correção genérica disponível"), "generic"));
    }
    if (signals.denuvo) {
      indicators.push(gameIndicator("shield", "Denuvo", t("Denuvo detectado"), "denuvo"));
    }
    if (signals.ea) {
      indicators.push(gameIndicator("plug", "EA App", t("EA app detectado"), "ea"));
    }
    if (signals.ubisoft) {
      indicators.push(gameIndicator("plug", "Ubisoft", t("Ubisoft Account detectado"), "ubisoft"));
    }
    if (signals.rockstar) {
      indicators.push(gameIndicator("plug", "Rockstar", t("Rockstar Games detectado"), "rockstar"));
    }

    if (!indicators.length) {
      removeGameIndicators();
      return;
    }

    var signature = indicators.map(function (item) {
      return item.kind + ":" + item.label;
    }).join("|");
    var current = document.querySelector(".skytools-game-indicators");
    if (current &&
        current.parentNode === communityButton.parentNode &&
        current.getAttribute("data-skytools-signature") === signature) {
      if (current.nextSibling !== communityButton) {
        communityButton.parentNode.insertBefore(current, communityButton);
      }
      return;
    }

    removeGameIndicators();
    var container = document.createElement("div");
    container.className = "skytools-game-indicators";
    container.setAttribute("data-skytools-signature", signature);
    container.setAttribute("aria-label", "SkyTools");
    for (var i = 0; i < indicators.length; i += 1) {
      var item = indicators[i];
      var badge = document.createElement("span");
      badge.className = "skytools-game-indicator skytools-game-indicator-" + item.kind;
      badge.title = item.title;
      badge.setAttribute("aria-label", item.title);
      badge.innerHTML = icon(item.iconName) + "<span>" + escapeHtml(item.label) + "</span>";
      container.appendChild(badge);
    }
    communityButton.parentNode.insertBefore(container, communityButton);
  }

  function ensureGameIndicators() {
    var appid = appIdFromUrl();
    if (!appid) {
      updateGameIndicators();
      return;
    }

    updateGameIndicators();
    if (state.indicatorCatalogAppId === appid) {
      return;
    }
    state.indicatorCatalogAppId = appid;
    refreshStoreFixCatalog().then(function () {
      if (appIdFromUrl() === appid) {
        updateGameIndicators();
      }
    });
  }

  function removeLegacyWebkitButton() {
    var old = document.querySelector("#skytools-add-button");
    if (old) {
      old.remove();
    }
    var oldStyle = document.querySelector("#skytools-style");
    if (oldStyle) {
      oldStyle.remove();
    }
  }

  function updateGameButton() {
    var button = document.querySelector(".skytools-game-button");
    if (!button) {
      return;
    }
    var appid = String(appIdFromUrl() || state.appid || "");
    var added = isCurrentAppAdded();
    var adding = !!(appid && state.addingAppId === appid);
    button.classList.toggle("skytools-game-button-remove", added && !adding);
    button.classList.toggle("skytools-game-button-loading", adding);
    button.disabled = adding || state.busy;
    button.setAttribute("aria-busy", adding ? "true" : "false");
    var nextHtml = "";
    var nextTitle = "";
    if (adding) {
      nextHtml = icon("spinner", "spin") + "<span>" + escapeHtml(t("Adicionando...")) + "</span>";
      nextTitle = t("Adicionando este jogo via SkyTools");
      if (button.innerHTML !== nextHtml) {
        button.innerHTML = nextHtml;
      }
      button.title = nextTitle;
      return;
    }
    nextHtml = icon(added ? "trash" : "add") + "<span>" + escapeHtml(added ? t("Remover via SkyTools") : t("Adicionar via SkyTools")) + "</span>";
    nextTitle = added ? t("Remover este jogo da biblioteca SkyTools") : t("Adicionar este jogo via SkyTools");
    if (button.innerHTML !== nextHtml) {
      button.innerHTML = nextHtml;
    }
    button.title = nextTitle;
  }

  function refreshInstalledCache(force, surfaceErrors) {
    if (state.installedLoading) {
      return state.installedPromise || Promise.resolve(state.installed);
    }
    if (!force && state.installed) {
      updateGameButton();
      return Promise.resolve(state.installed);
    }
    state.installedLoading = true;
    state.installedPromise = call("SkyToolsInstalled", { force: force === true }).then(function (result) {
      applyInstalledResult(result);
      return result;
    }, function (error) {
      log("SkyToolsInstalled: " + (error && error.message ? error.message : String(error)));
      if (surfaceErrors) {
        throw error;
      }
      return state.installed;
    }).then(function (result) {
      state.installedLoading = false;
      state.installedPromise = null;
      return result;
    }, function (error) {
      state.installedLoading = false;
      state.installedPromise = null;
      throw error;
    });
    return state.installedPromise;
  }

  function refreshFixGames(force) {
    if (state.fixGamesLoading) {
      return state.fixGamesPromise || Promise.resolve(state.fixGames);
    }
    if (!force && state.fixGames) {
      return Promise.resolve(state.fixGames);
    }
    state.fixGamesLoading = true;
    state.fixGamesPromise = call("SkyToolsSteamInstalled", {}).then(function (result) {
      state.fixGames = result;
      return result;
    }, function (error) {
      log("SkyToolsSteamInstalled: " + (error && error.message ? error.message : String(error)));
      state.fixGames = { success: false, error: error && error.message ? error.message : String(error) };
      return state.fixGames;
    }).then(function (result) {
      state.fixGamesLoading = false;
      state.fixGamesPromise = null;
      return result;
    });
    return state.fixGamesPromise;
  }

  function updateFixAvailabilityFromCatalog(result) {
    var data = normalizeData(result) || {};
    var ids = Array.isArray(data.availableAppIds) ? data.availableAppIds : [];
    var games = Array.isArray(data.games) ? data.games : [];
    var map = {};
    var kindsMap = {};
    for (var i = 0; i < ids.length; i += 1) {
      var appid = String(ids[i] || "");
      if (appid) {
        map[appid] = true;
      }
    }
    for (var gameIndex = 0; gameIndex < games.length; gameIndex += 1) {
      var game = games[gameIndex] || {};
      var gameAppid = String(game.appId || game.appid || "");
      if (!gameAppid) {
        continue;
      }
      map[gameAppid] = true;
      kindsMap[gameAppid] = kindsMap[gameAppid] || {};
      var assets = Array.isArray(game.assets) ? game.assets : [];
      for (var assetIndex = 0; assetIndex < assets.length; assetIndex += 1) {
        var kind = String((assets[assetIndex] || {}).kind || "").toLowerCase();
        if (kind === "online" || kind === "generic") {
          kindsMap[gameAppid][kind] = true;
        }
      }
    }
    state.fixAvailableMap = map;
    state.fixKindsMap = kindsMap;
    state.fixCatalogLoadedAt = Date.now();
    updateGameIndicators();
  }

  function fixCatalogSize(bytes) {
    var value = Number(bytes || 0);
    if (!isFinite(value) || value <= 0) {
      return "";
    }
    return (value / 1024 / 1024).toFixed(1).replace(".", ",") + " MB";
  }

  function fixCatalogFromRelease(release) {
    var releaseAssets = release && Array.isArray(release.assets) ? release.assets : [];
    var byAppId = {};
    var matchedAssets = 0;
    for (var i = 0; i < releaseAssets.length; i += 1) {
      var asset = releaseAssets[i] || {};
      var fileName = String(asset.name || "");
      var match = /^(\d+)_(online|generic)\.(zip|rar|7z)$/i.exec(fileName);
      if (!match) {
        continue;
      }
      var appid = match[1];
      if (!byAppId[appid]) {
        byAppId[appid] = { appId: appid, hasAvailableFix: true, assets: [] };
      }
      var sizeBytes = Number(asset.size || 0) || 0;
      byAppId[appid].assets.push({
        fileName: fileName,
        kind: String(match[2] || "").toLowerCase(),
        downloadUrl: String(asset.browser_download_url || ""),
        sizeBytes: sizeBytes,
        size: fixCatalogSize(sizeBytes)
      });
      matchedAssets += 1;
    }

    var availableAppIds = Object.keys(byAppId).sort(function (left, right) {
      return Number(left) - Number(right);
    });
    return {
      success: true,
      data: {
        tag: String(release && release.tag_name || "fix"),
        releaseUpdatedAt: String(release && release.updated_at || ""),
        fetchedAt: Date.now(),
        releaseAssetCount: releaseAssets.length,
        fixAssetCount: matchedAssets,
        availableAppIds: availableAppIds,
        games: availableAppIds.map(function (appid) { return byAppId[appid]; })
      },
      error: ""
    };
  }

  function applyBrowserFixCatalog(result) {
    state.fixCatalog = result;
    if (result && result.success !== false) {
      updateFixAvailabilityFromCatalog(result);
      writeFixCatalogSnapshot(result);
    }
    return result;
  }

  function refreshStoreFixCatalog() {
    var expired = !state.fixCatalogLoadedAt || Date.now() - state.fixCatalogLoadedAt >= FIX_CATALOG_SNAPSHOT_TTL;
    if (!expired && state.fixCatalog) {
      return Promise.resolve(state.fixCatalog);
    }
    if (state.storeFixCatalogLoading) {
      return state.storeFixCatalogPromise || Promise.resolve(state.fixCatalog);
    }

    var snapshot = readFixCatalogSnapshot();
    if (snapshot) {
      return Promise.resolve(applyBrowserFixCatalog(snapshot));
    }
    if (typeof window.fetch !== "function") {
      return Promise.resolve(null);
    }

    state.storeFixCatalogLoading = true;
    var separator = FIX_CATALOG_RELEASE_URL.indexOf("?") >= 0 ? "&" : "?";
    state.storeFixCatalogPromise = window.fetch(FIX_CATALOG_RELEASE_URL + separator + "skytools=" + Date.now(), {
      method: "GET",
      cache: "no-store",
      credentials: "omit",
      headers: {
        "Accept": "application/vnd.github+json"
      }
    }).then(function (response) {
      if (!response.ok) {
        throw new Error("GitHub respondeu HTTP " + response.status);
      }
      return response.json();
    }).then(function (release) {
      return applyBrowserFixCatalog(fixCatalogFromRelease(release));
    }, function (error) {
      log("Catálogo visual: " + (error && error.message ? error.message : String(error)));
      return null;
    }).then(function (result) {
      state.storeFixCatalogLoading = false;
      state.storeFixCatalogPromise = null;
      return result;
    }, function (error) {
      state.storeFixCatalogLoading = false;
      state.storeFixCatalogPromise = null;
      log("Catálogo visual: " + (error && error.message ? error.message : String(error)));
      return null;
    });
    return state.storeFixCatalogPromise;
  }

  function refreshFixCatalog(force) {
    if (state.fixCatalogLoading) {
      return state.fixCatalogPromise || Promise.resolve(state.fixCatalog);
    }
    var expired = !state.fixCatalogLoadedAt || Date.now() - state.fixCatalogLoadedAt >= 60000;
    if (!force && !expired && state.fixCatalog) {
      return Promise.resolve(state.fixCatalog);
    }

    state.fixCatalogLoading = true;
    state.fixCatalogPromise = call("SkyToolsFixCatalog", { force: force === true || expired }).then(function (result) {
      state.fixCatalog = result;
      if (result && result.success !== false) {
        updateFixAvailabilityFromCatalog(result);
      }
      return result;
    }, function (error) {
      log("SkyToolsFixCatalog: " + (error && error.message ? error.message : String(error)));
      state.fixCatalog = { success: false, error: error && error.message ? error.message : String(error) };
      return state.fixCatalog;
    }).then(function (result) {
      state.fixCatalogLoading = false;
      state.fixCatalogPromise = null;
      return result;
    });
    return state.fixCatalogPromise;
  }

  function refreshApisCache(force) {
    if (state.apisLoading) {
      return state.apisPromise || Promise.resolve(state.apis);
    }
    if (!force && state.apis) {
      return Promise.resolve(state.apis);
    }
    state.apisLoading = true;
    state.apisPromise = call("SkyToolsApis", {}).then(function (result) {
      state.apis = result;
      return result;
    }, function (error) {
      log("SkyToolsApis: " + (error && error.message ? error.message : String(error)));
      return state.apis;
    }).then(function (result) {
      state.apisLoading = false;
      state.apisPromise = null;
      return result;
    });
    return state.apisPromise;
  }

  function ensureGameButton() {
    var appid = appIdFromUrl();
    if (!appid) {
      removeGameButton();
      return;
    }

    state.appid = appid;
    state.appName = appNameFromPage();

    if (document.querySelector(".skytools-game-button")) {
      updateGameButton();
      return;
    }

    var target = buttonTarget();
    if (!target) {
      return;
    }

    var button = document.createElement("button");
    button.type = "button";
    button.className = "skytools-game-button";
    button.addEventListener("click", function () {
      if (button.disabled || state.addingAppId) {
        showToast("SkyTools", "Aguarde a adição terminar.", "info");
        return;
      }
      if (isCurrentAppAdded()) {
        removeCurrentGame();
      } else {
        addCurrentGame(appid);
      }
    });
    updateGameButton();
    target.appendChild(button);
    updateGameButton();
  }

  function ensureFloatingMenu() {
    if (!document.body || document.querySelector(".skytools-fab-shell")) {
      return;
    }

    var shell = document.createElement("div");
    shell.className = "skytools-fab-shell";

    var button = document.createElement("button");
    button.type = "button";
    button.className = "skytools-fab";
    button.innerHTML = '<span class="skytools-fab-logo"></span><span>SkyTools</span>';
    button.title = "SkyTools Plugin";
    button.addEventListener("click", togglePanel);

    var toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "skytools-fab-toggle";
    toggle.addEventListener("click", function (event) {
      event.preventDefault();
      event.stopPropagation();
      state.fabCollapsed = !state.fabCollapsed;
      writeStoredFabCollapsed(state.fabCollapsed);
      updateFloatingMenu();
    });

    shell.appendChild(button);
    shell.appendChild(toggle);
    document.body.appendChild(shell);
    updateFloatingMenu();
  }

  function updateFloatingMenu() {
    var shell = document.querySelector(".skytools-fab-shell");
    if (!shell) {
      return;
    }
    var collapsed = state.fabCollapsed === true;
    shell.classList.toggle("skytools-fab-collapsed", collapsed);
    document.documentElement.classList.toggle("skytools-fab-is-collapsed", collapsed);
    var button = shell.querySelector(".skytools-fab");
    if (button) {
      button.tabIndex = collapsed ? -1 : 0;
      button.setAttribute("aria-hidden", collapsed ? "true" : "false");
    }
    var toggle = shell.querySelector(".skytools-fab-toggle");
    if (toggle) {
      var toggleHtml = icon(collapsed ? "chevronLeft" : "chevronRight");
      if (toggle.innerHTML !== toggleHtml) {
        toggle.innerHTML = toggleHtml;
      }
      toggle.title = collapsed ? t("Mostrar botão SkyTools") : t("Minimizar botão SkyTools");
      toggle.setAttribute("aria-label", toggle.title);
    }
  }

  function closePanel() {
    var panel = document.querySelector(".skytools-panel");
    if (panel) {
      panel.remove();
    }
  }

  function togglePanel() {
    if (document.querySelector(".skytools-panel")) {
      closePanel();
      return;
    }
    openPanel();
  }

  function findActionButton(target) {
    var node = target;
    while (node && node !== document) {
      if (node.getAttribute && node.getAttribute("data-action")) {
        return node;
      }
      node = node.parentNode;
    }
    return null;
  }

  function findGameSettingsNode(target) {
    var node = target;
    while (node && node !== document) {
      if (node.getAttribute && node.getAttribute("data-game-settings-appid")) {
        return node;
      }
      node = node.parentNode;
    }
    return null;
  }

  function findTabButton(target) {
    var node = target;
    while (node && node !== document) {
      if (node.getAttribute && node.getAttribute("data-tab")) {
        return node;
      }
      node = node.parentNode;
    }
    return null;
  }

  function actionCard(action, iconName, title, detail, primary, loading) {
    return [
      '<button type="button" class="skytools-action-card ' + (primary ? "skytools-primary-action" : "") + (loading ? " skytools-action-loading" : "") + '" data-action="' + action + '"' + (loading ? ' aria-busy="true" disabled' : "") + '>',
      '  <span class="skytools-action-icon">' + icon(iconName, loading ? "spin" : "") + '</span>',
      '  <span class="skytools-action-copy"><strong>' + escapeHtml(title) + '</strong><small>' + escapeHtml(detail) + '</small></span>',
      '</button>'
    ].join("");
  }

  function addGameControl(app) {
    var appid = normalizeAppIdInput(state.addAppIdInput || app.appid || "");
    var loading = !!(state.addingAppId && state.addingAppId === appid);
    return [
      '<div class="skytools-add-game">',
      '  <div class="skytools-field"><label for="skytools-add-appid">Adicionar jogo por AppID</label><input id="skytools-add-appid" class="skytools-input" data-field="addGameAppId" inputmode="numeric" pattern="[0-9]*" autocomplete="off" placeholder="Digite o AppID do jogo" value="' + escapeHtml(appid) + '"' + (loading ? ' disabled' : '') + '></div>',
      '  <button type="button" class="skytools-add-game-button" data-action="add"' + (loading ? ' aria-busy="true" disabled' : '') + '>' + icon(loading ? "spinner" : "add", loading ? "spin" : "") + '<span>' + escapeHtml(loading ? "Adicionando..." : "Adicionar") + '</span></button>',
      '</div>'
    ].join("");
  }

  function metric(label, value) {
    return '<div class="skytools-metric"><span>' + escapeHtml(label) + '</span><strong>' + escapeHtml(value) + '</strong></div>';
  }

  function statusMetrics() {
    var data = normalizeData(state.status) || {};
    var app = currentPayload();
    var installedCount = state.installed ? gameArray(state.installed).length : data.installedCount;
    return [
      metric("Jogo atual", app.appid ? app.name + " (" + app.appid + ")" : "Nenhum"),
      metric("Integracao", data.integration || data.configuredIntegration || "Detectando"),
      metric("Jogos na biblioteca", installedCount != null ? installedCount : "-")
    ].join("");
  }

  function renderGameSettings(game, appid) {
    if (String(state.expandedGameSettingsAppId || "") !== String(appid)) {
      return "";
    }
    var depotId = String(game.luaDepotId || game.LuaDepotId || "");
    var manifestId = String(game.luaManifestId || game.LuaManifestId || "");
    var dlcs = Array.isArray(game.dlcs) ? game.dlcs : (Array.isArray(game.Dlcs) ? game.Dlcs : []);
    var dlcRows = [];
    for (var i = 0; i < dlcs.length; i += 1) {
      var dlc = dlcs[i] || {};
      var dlcId = String(dlc.id || dlc.Id || "");
      if (!dlcId) {
        continue;
      }
      var enabled = dlc.enabled === true || dlc.Enabled === true;
      var label = String(dlc.label || dlc.Label || "").trim();
      dlcRows.push([
        '<label class="skytools-game-dlc">',
        '  <input type="checkbox" data-game-dlc-id="' + escapeHtml(dlcId) + '"' + (enabled ? " checked" : "") + '>',
        '  <span><strong>' + escapeHtml(label || ("DLC " + dlcId)) + '</strong><small>ID ' + escapeHtml(dlcId) + '</small></span>',
        '</label>'
      ].join(""));
    }
    return [
      '<div class="skytools-game-settings" data-game-settings-appid="' + escapeHtml(appid) + '">',
      '  <div class="skytools-game-settings-title"><strong>Versão do jogo</strong><span>AppID ' + escapeHtml(appid) + '</span></div>',
      '  <div class="skytools-game-manifest-fields">',
      '    <div class="skytools-field"><label>DepotID</label><input class="skytools-input" inputmode="numeric" data-game-setting="depot-id" data-initial-value="' + escapeHtml(depotId) + '" value="' + escapeHtml(depotId) + '" placeholder="' + escapeHtml(String(Number(appid) + 1)) + '"></div>',
      '    <div class="skytools-field"><label>ManifestID</label><input class="skytools-input" inputmode="numeric" data-game-setting="manifest-id" data-initial-value="' + escapeHtml(manifestId) + '" value="' + escapeHtml(manifestId) + '" placeholder="0000000000000000000"></div>',
      '  </div>',
      '  <div class="skytools-game-settings-title"><strong>DLCs do Lua</strong><span>' + escapeHtml(String(dlcs.length)) + '</span></div>',
      '  <div class="skytools-game-dlc-list">' + (dlcRows.length ? dlcRows.join("") : '<div class="skytools-game-settings-empty">Nenhuma DLC encontrada.</div>') + '</div>',
      '  <button type="button" class="skytools-game-settings-save" data-action="save-game-settings" data-appid="' + escapeHtml(appid) + '">' + icon("save", "fa-solid fa-floppy-disk") + '<span>Salvar configurações</span></button>',
      '</div>'
    ].join("");
  }

  function renderInstalledList() {
    var list = gameArray(state.installed);
    var query = String(state.libraryQuery || "").toLowerCase();
    if (!list || !list.length) {
      return '<div class="skytools-empty">Nenhum jogo carregado ainda.</div>';
    }

    var rows = [];
    for (var i = 0; i < list.length; i += 1) {
      var game = list[i];
      var appid = gameAppId(game);
      var name = displayGameName(game);
      if (query && String(name).toLowerCase().indexOf(query) < 0 && String(appid).indexOf(query) < 0) {
        continue;
      }
      var dlcCount = Number(game.dlcCount || game.DlcCount || game.dlc_count || 0);
      var pill = dlcCount === 1 ? "1 DLC" : dlcCount > 1 ? (dlcCount + " DLCs") : "0 DLCs";
      var updatesLocked = game.updatesLocked === true || game.UpdatesLocked === true;
      var isSteamInstalled = game.isSteamInstalled === true || game.IsSteamInstalled === true;
      var canLockUpdates = isSteamInstalled
        && String(game.manifestPath || game.ManifestPath || "").trim()
        && String(game.mainDepotId || game.MainDepotId || "").trim()
        && String(game.mainManifestId || game.MainManifestId || "").trim();
      var lockButton = canLockUpdates
        ? '  <button type="button" class="skytools-row-action skytools-update-lock' + (updatesLocked ? ' skytools-update-locked' : '') + '" title="' + (updatesLocked ? "Destravar atualizações" : "Travar atualizações") + '" aria-label="' + (updatesLocked ? "Destravar atualizações" : "Travar atualizações") + '" data-action="toggle-update-lock" data-appid="' + escapeHtml(appid) + '" data-locked="' + (updatesLocked ? "true" : "false") + '">' + icon(updatesLocked ? "lock" : "lockOpen", updatesLocked ? "fa-solid fa-lock" : "fa-solid fa-lock-open") + '</button>'
        : (!isSteamInstalled
          ? '  <button type="button" class="skytools-row-action skytools-install-game" title="Instalar jogo" aria-label="Instalar jogo" data-action="install-game" data-appid="' + escapeHtml(appid) + '">' + icon("download", "fa-solid fa-download") + '</button>'
          : "");
      var settingsOpen = String(state.expandedGameSettingsAppId || "") === String(appid);
      var gearButton = '  <button type="button" class="skytools-row-action skytools-game-settings-toggle' + (settingsOpen ? ' active' : '') + '" title="Configurar jogo" aria-label="Configurar jogo" aria-expanded="' + (settingsOpen ? "true" : "false") + '" data-action="toggle-game-settings" data-appid="' + escapeHtml(appid) + '">' + icon("gear", "fa-solid fa-gear" + (String(state.gearSpinAppId || "") === String(appid) ? " skytools-gear-spin" : "")) + '</button>';
      rows.push([
        '<div class="skytools-library-item">',
        '<div class="skytools-list-row' + (settingsOpen ? ' skytools-list-row-expanded' : '') + '">',
        '  <div class="skytools-row-icon">' + icon("library") + '</div>',
        '  <div class="skytools-row-main" title="' + escapeHtml(name) + '"><strong>' + escapeHtml(name) + '</strong><span>AppID ' + escapeHtml(appid) + '</span></div>',
        '  <span class="skytools-pill">' + escapeHtml(pill) + '</span>',
        gearButton,
        lockButton,
        '  <button type="button" class="skytools-row-action" title="Remover da Steam" data-action="remove-game" data-appid="' + escapeHtml(appid) + '" data-name="' + escapeHtml(name) + '">' + icon("trash") + '</button>',
        '</div>',
        renderGameSettings(game, appid),
        '</div>'
      ].join(""));
    }
    return rows.length ? rows.join("") : '<div class="skytools-empty">Nenhum jogo encontrado com esse filtro.</div>';
  }

  function applyInstalledUpdateLock(appid, locked) {
    var id = String(appid || "");
    var list = gameArray(state.installed);
    for (var i = 0; i < list.length; i += 1) {
      if (String(gameAppId(list[i])) === id) {
        list[i].updatesLocked = locked === true;
        list[i].UpdatesLocked = locked === true;
        break;
      }
    }
    writeInstalledSnapshot(state.installed);
  }

  function applyInstalledGameSettings(appid, data) {
    var id = String(appid || "");
    var list = gameArray(state.installed);
    for (var i = 0; i < list.length; i += 1) {
      if (String(gameAppId(list[i])) !== id) {
        continue;
      }
      list[i].dlcCount = Number(data.dlcCount || 0);
      list[i].dlcAppIds = Array.isArray(data.dlcAppIds) ? data.dlcAppIds : [];
      list[i].dlcs = Array.isArray(data.dlcs) ? data.dlcs : [];
      list[i].activeManifestDepotIds = Array.isArray(data.activeManifestDepotIds) ? data.activeManifestDepotIds : [];
      list[i].luaDepotId = String(data.luaDepotId || "");
      list[i].luaManifestId = String(data.luaManifestId || "");
      list[i].updatesLocked = data.updatesLocked === true;
      list[i].UpdatesLocked = data.updatesLocked === true;
      break;
    }
    writeInstalledSnapshot(state.installed);
  }

  function renderApisList() {
    var data = normalizeData(state.apis);
    if (!data) {
      return '<div class="skytools-empty">Carregando APIs...</div>';
    }

    var builtIn = apiListFromData(data.builtIn).filter(isValidApi);
    var custom = apiListFromData(data.custom).filter(isValidApi);
    var allApis = orderApis(builtIn.concat(custom), state.apiOrder || readStoredApiOrder() || data.apiOrder || data.ApiOrder || defaultApiOrder());
    state.apiOrder = allApis.map(function (api) { return apiId(api); }).filter(Boolean);

    var apiRows = allApis.map(function (api) {
      var id = api.id || api.Id || "";
      var name = api.name || api.Name || "API sem nome";
      var url = api.urlTemplate || api.UrlTemplate || "";
      var enabled = api.enabled !== false && api.Enabled !== false;
      var nativeApi = api.native === true || api.Native === true;
      var useProxy = api.useProxy === true || api.UseProxy === true;
      var success = api.successCode || api.SuccessCode || 200;
      var unavailable = api.unavailableCode || api.UnavailableCode || 404;
      var detail = t(enabled ? "Ativa" : "Desativada") + " · " + t(nativeApi ? "API padrão" : "API personalizada") + " · HTTP " + success + "/" + unavailable + (useProxy ? " · proxy" : "");
      return [
        '<div class="skytools-custom-api-row skytools-api-draggable ' + (state.apiForm && state.apiForm.id === id ? "selected" : "") + '" draggable="true" data-api-id="' + escapeHtml(id) + '">',
        '  <span class="skytools-drag-handle" title="Arrastar para ordenar">' + icon("api") + '</span>',
        '  <div class="skytools-row-main"><strong>' + escapeHtml(name) + '</strong><span>' + escapeHtml(url || "URL não configurada") + '</span><small>' + escapeHtml(detail) + '</small></div>',
        '  <div class="skytools-row-actions">',
        '    <button type="button" class="skytools-row-action" title="Editar API" data-action="api-edit" data-api-id="' + escapeHtml(id) + '">' + icon("pencil") + '</button>',
        '    <button type="button" class="skytools-row-action skytools-danger-action" title="Excluir API" data-action="api-delete" data-api-id="' + escapeHtml(id) + '">' + icon("trash") + '</button>',
        '  </div>',
        '</div>'
      ].join("");
    });

    var form = state.apiForm;
    var editor = "";
    if (form) {
      editor = [
        '<div class="skytools-api-editor">',
        '  <div class="skytools-card-head"><div><strong>' + escapeHtml(form.id ? "Editar API" : "Adicionar API") + '</strong><span>Use <appid> na URL. Use <apikey> quando a fonte exigir chave.</span></div><button type="button" data-action="api-cancel">' + icon("close") + '<span>Fechar</span></button></div>',
        '  <div class="skytools-form-row">',
        '    <div class="skytools-field skytools-grow"><label>Nome</label><input class="skytools-input" data-field="apiName" value="' + escapeHtml(form.name || "") + '"></div>',
        '    <label class="skytools-setting-toggle"><span><strong>Ativa</strong><small>Usar nas instalações.</small></span><input type="checkbox" data-field="apiEnabled"' + (form.enabled === false ? "" : " checked") + '></label>',
        '  </div>',
        '  <div class="skytools-field"><label>URL da API</label><input class="skytools-input" data-field="apiUrl" placeholder="https://exemplo.com/download?appid=<appid>&key=<apikey>" value="' + escapeHtml(form.urlTemplate || "") + '"></div>',
        '  <div class="skytools-form-row">',
        '    <div class="skytools-field skytools-grow"><label>API key</label><input class="skytools-input" type="password" data-field="apiKey" value="' + escapeHtml(form.apiKey || "") + '"></div>',
        '    <label class="skytools-setting-toggle"><span><strong>Proxy</strong><small>Encapsular URL.</small></span><input type="checkbox" data-field="apiUseProxy"' + (form.useProxy ? " checked" : "") + '></label>',
        '  </div>',
        '  <div class="skytools-field"><label>URL do proxy</label><input class="skytools-input" data-field="apiProxyUrl" placeholder="https://proxy.exemplo.com/?url=<url>" value="' + escapeHtml(form.proxyUrlTemplate || "") + '"></div>',
        '  <div class="skytools-form-row">',
        '    <div class="skytools-field"><label>HTTP sucesso</label><input class="skytools-input" type="number" min="100" max="599" data-field="apiSuccessCode" value="' + escapeHtml(form.successCode || 200) + '"></div>',
        '    <div class="skytools-field"><label>HTTP indisponível</label><input class="skytools-input" type="number" min="100" max="599" data-field="apiUnavailableCode" value="' + escapeHtml(form.unavailableCode || 404) + '"></div>',
        '  </div>',
        '  <div class="skytools-button-row">',
        '    <button type="button" data-action="api-save">' + icon("check") + '<span>Salvar API</span></button>',
        '  </div>',
        '</div>'
      ].join("");
    }

    return [
      '<div class="skytools-api-panel">',
      '  <section class="skytools-api-card">',
      '    <div class="skytools-card-head"><div><strong>APIs de download</strong><span>Arraste para definir a ordem de tentativa.</span></div><button type="button" data-action="api-new">' + icon("add") + '<span>Adicionar</span></button></div>',
      apiRows.length ? '<div class="skytools-custom-api-list">' + apiRows.join("") + '</div>' : '<div class="skytools-empty">Nenhuma API configurada.</div>',
      editor,
      '  </section>',
      '</div>'
    ].join("");
  }

  function sourceArray(result) {
    var data = normalizeData(result);
    if (Array.isArray(data)) return data;
    if (data && Array.isArray(data.sources)) return data.sources;
    return [];
  }

  function sourceUrl(source) {
    source = source || {};
    return source.downloadUrl || source.DownloadUrl || source.downloadURL || source.sourceUrl || source.SourceUrl || source.url || source.Url || source.href || source.link || "";
  }

  function looksLikeArchive(value) {
    return /\.(zip|rar|7z)(?:\?|$)/i.test(String(value || ""));
  }

  function translateFixText(value) {
    var text = String(value || "");
    if (!text) {
      return text;
    }
    return text
      .replace(/\bGen[eé]rica\b/gi, t("Genérica"))
      .replace(/\bGeneric\b/gi, t("Generic"))
      .replace(/\bOnline\b/gi, t("Online"));
  }

  function formatFixLabel(source) {
    source = source || {};
    if (source.displayName) return translateFixText(source.displayName);
    var name = source.name || source.title || source.fileName || source.provider || "Fonte";
    var type = translateFixText(source.type || "");
    var size = source.size || "";
    var provider = source.provider || "Sky";
    var label = name;
    if (type) label += " - " + type;
    if (size) label += " - " + size;
    if (provider) label += " (" + provider + ")";
    return label;
  }

  function renderFixResults() {
    var sources = sourceArray(state.fixResults);
    if (!sources.length) {
      return '<div class="skytools-empty">Nenhuma correção Sky carregada.</div>';
    }
    return sources.map(function (source, index) {
      var title = formatFixLabel(source);
      var detail = source.fileName || [source.provider, translateFixText(source.type), source.size].filter(Boolean).join(" · ");
      var url = sourceUrl(source);
      var canApply = looksLikeArchive(url) || looksLikeArchive(title);
      var actionButton = canApply
        ? '  <button type="button" class="skytools-row-action" title="Aplicar na pasta do jogo" data-action="fix-prepare" data-source-index="' + index + '">' + icon("check") + '</button>'
        : '  <button type="button" class="skytools-row-action" title="Pacote não suportado" disabled>' + icon("error") + '</button>';
      return [
        '<div class="skytools-list-row">',
        '  <div class="skytools-row-icon">' + icon("fixes") + '</div>',
        '  <div class="skytools-row-main"><strong>' + escapeHtml(title) + '</strong><span>' + escapeHtml(detail || url) + '</span></div>',
        actionButton,
        '</div>'
      ].join("");
    }).join("");
  }

  function renderFixGamePicker() {
    var list = gameArray(state.fixGames);
    var query = String(state.fixQuery || "").toLowerCase();
    var visibleLimit = Math.max(40, Number(state.fixVisibleCount || 80));
    if (!list.length) {
      if (state.fixGamesLoading) {
        return '<div class="skytools-empty">Carregando jogos instalados...</div>';
      }
      var error = state.fixGames && state.fixGames.error ? String(state.fixGames.error) : "";
      return '<div class="skytools-empty">' + escapeHtml(error || "Nenhum jogo instalado encontrado nas bibliotecas Steam.") + '</div>';
    }

    var rows = [];
    var matched = 0;
    for (var i = 0; i < list.length; i += 1) {
      var game = list[i];
      var appid = gameAppId(game);
      var name = displayGameName(game);
      if (query && (String(name).toLowerCase().indexOf(query) < 0 && String(appid).indexOf(query) < 0)) {
        continue;
      }
      matched += 1;
      if (rows.length >= visibleLimit) {
        continue;
      }
      var removeButton = game.hasAppliedFix
        ? '  <button type="button" class="skytools-row-action" title="Remover correção e verificar integridade" data-action="fix-remove" data-appid="' + escapeHtml(appid) + '" data-name="' + escapeHtml(name) + '">' + icon("trash") + '</button>'
        : "";
      var availableBadge = state.fixAvailableMap[String(appid)]
        ? '<span class="skytools-fix-available">' + icon("check") + escapeHtml(t("Correção disponível")) + '</span>'
        : "";
      rows.push([
        '<div class="skytools-list-row">',
        '  <div class="skytools-row-icon">' + icon("library") + '</div>',
        '  <div class="skytools-row-main"><div class="skytools-row-title"><strong>' + escapeHtml(name) + '</strong>' + availableBadge + '</div><span>AppID ' + escapeHtml(appid) + '</span></div>',
        removeButton,
        '  <button type="button" class="skytools-row-action" title="Buscar correções" data-action="fix-game" data-appid="' + escapeHtml(appid) + '" data-name="' + escapeHtml(name) + '" data-game-path="' + escapeHtml(game.gamePath || game.installPath || "") + '">' + icon("fixes") + '</button>',
        '</div>'
      ].join(""));
    }
    if (matched > rows.length) {
      rows.push('<button type="button" class="skytools-load-more" data-action="fix-load-more">Mostrar mais ' + escapeHtml(String(Math.min(120, matched - rows.length))) + ' de ' + escapeHtml(String(matched - rows.length)) + '</button>');
    }
    state.fixMatchedCount = matched;
    return rows.length ? rows.join("") : '<div class="skytools-empty">Nenhum jogo encontrado com esse filtro.</div>';
  }

  function renderBackupPanel() {
    var backup = state.backup;
    var games = backup && Array.isArray(backup.games) ? backup.games : [];
    return [
      '<div class="skytools-grid skytools-tight-grid">',
      actionCard("backup-export", "backup", "Exportar backup", "Salvar biblioteca em JSON", false),
      actionCard("backup-restore", "backup", "Restaurar ausentes", games.length ? (games.length + " jogo(s) carregado(s)") : "Carregue um backup", false),
      '</div>',
      '<div class="skytools-form">',
      '  <label>Arquivo de backup</label>',
      '  <label class="skytools-file-picker">' + icon("folder") + '<span>Escolher arquivo</span><small data-role="backup-file-name">Nenhum arquivo escolhido</small><input type="file" accept="application/json,.json" data-action="backup-file"></label>',
      '</div>',
      backup ? '<pre class="skytools-result">' + escapeHtml(JSON.stringify({ createdAt: backup.createdAt, games: games.slice(0, 20), total: games.length }, null, 2)) + '</pre>' : '<div class="skytools-empty">Nenhum backup carregado.</div>'
    ].join("");
  }

  function renderDiagnostics() {
    var result = state.lastResult || state.status;
    if (!result) {
      return '<div class="skytools-empty">Sem dados ainda.</div>';
    }
    return '<pre class="skytools-result">' + escapeHtml(JSON.stringify(result, null, 2)) + '</pre>';
  }

  function renderThemeOptions() {
    var themes = themeArray(state.status);
    state.themes = themes;
    var rows = [];
    for (var i = 0; i < themes.length; i += 1) {
      var theme = themes[i];
      rows.push(
        '<option value="' + escapeHtml(theme.id) + '"' + (String(theme.id) === String(state.themeId) ? " selected" : "") + '>' +
        escapeHtml(theme.name || theme.id) +
        '</option>'
      );
    }
    return rows.join("");
  }

  function renderLanguageOptions() {
    var rows = [];
    var current = normalizeLanguageId(state.languageMode);
    for (var i = 0; i < SUPPORTED_LANGUAGES.length; i += 1) {
      var language = SUPPORTED_LANGUAGES[i];
      rows.push(
        '<option value="' + escapeHtml(language.id) + '"' + (language.id === current ? " selected" : "") + '>' +
        escapeHtml(language.id === "auto" ? t(language.label) : language.label) +
        '</option>'
      );
    }
    return rows.join("");
  }

  function renderSettings() {
    return [
      '<div class="skytools-form">',
      '  <div class="skytools-field"><label>Idioma</label><select class="skytools-input" data-field="languageSelect">' + renderLanguageOptions() + '</select></div>',
      '  <div class="skytools-field"><label>Tema</label><select class="skytools-input" data-field="themeSelect">' + renderThemeOptions() + '</select></div>',
      '</div>',
      '<div class="skytools-grid skytools-tight-grid">',
      actionCard("integration-skytools", "plug", "Ativar SkyTools", "Instalar integração Steam", false),
      actionCard("integration-steamtools", "plug", "Ativar SteamTools", "Alternativa compatível", false),
      '</div>',
      renderDiagnostics()
    ].join("");
  }

  function tabMarkup(tab) {
    var app = currentPayload();
    if (tab === "biblioteca") {
      return [
        '<div class="skytools-section-head"><strong>Jogos instalados</strong><button data-action="installed" type="button">' + icon("refresh") + '<span>Atualizar</span></button></div>',
        '<div class="skytools-field"><label>Buscar na biblioteca</label><input class="skytools-input" data-field="librarySearch" placeholder="Digite nome ou AppID" value="' + escapeHtml(state.libraryQuery || "") + '"></div>',
        '<div class="skytools-list" data-role="installed-list">' + renderInstalledList() + '</div>'
      ].join("");
    }

    if (tab === "correcoes") {
      return [
        '<div class="skytools-section-head"><strong>Correções para jogo</strong><button data-action="refresh-fix-games" type="button">' + icon("refresh") + '<span>Atualizar</span></button></div>',
        '<div class="skytools-field"><label>Buscar jogo instalado</label><input class="skytools-input" data-field="fixSearch" placeholder="Digite nome ou AppID" value="' + escapeHtml(state.fixQuery || "") + '"></div>',
        '<div class="skytools-list skytools-scroll-list skytools-fix-game-list" data-role="fix-game-list">' + renderFixGamePicker() + '</div>',
        '<div class="skytools-section-head"><strong>' + escapeHtml(state.selectedFixGame ? ("Resultados para " + state.selectedFixGame.name) : "Resultados") + '</strong></div>',
        '<div class="skytools-list">' + renderFixResults() + '</div>'
      ].join("");
    }

    if (tab === "apis") {
      return [
        '<div class="skytools-section-head"><strong>APIs</strong><button data-action="apis" type="button">' + icon("refresh") + '<span>Atualizar</span></button></div>',
        '<div class="skytools-list">' + renderApisList() + '</div>'
      ].join("");
    }

    if (tab === "configuracoes") {
      return [
        '<div class="skytools-section-head"><strong>Configurações</strong><button data-action="status" type="button">' + icon("refresh") + '<span>Atualizar</span></button></div>',
        renderSettings()
      ].join("");
    }

    if (tab === "backup") {
      return [
        '<div class="skytools-section-head"><strong>Backup</strong><button data-action="backup-export" type="button">' + icon("backup") + '<span>Exportar</span></button></div>',
        renderBackupPanel()
      ].join("");
    }

    return [
      '<div class="skytools-current">',
      '  <div class="skytools-current-art">' + icon("library") + '</div>',
      '  <div><span>App atual</span><strong>' + escapeHtml(app.appid ? app.name : "Nenhum jogo aberto") + '</strong><small>' + escapeHtml(app.appid ? "AppID " + app.appid : "Nenhuma página de jogo detectada.") + '</small></div>',
      '</div>',
      '<div class="skytools-metrics">' + statusMetrics() + '</div>',
      '<div class="skytools-grid">',
      addGameControl(app),
      actionCard("correcoes-tab", "fixes", "Correções", "Buscar por jogo instalado", false),
      '</div>'
    ].join("");
  }

  function pluginTitleFromStatus() {
    var statusData = normalizeData(state.status) || {};
    var pluginVersion = String(statusData.pluginVersion || "").trim();
    return "SkyTools Plugin" + (pluginVersion ? " " + pluginVersion : "");
  }

  function updatePluginTitle() {
    var title = document.querySelector(".skytools-panel .skytools-brand strong");
    if (title) {
      title.textContent = pluginTitleFromStatus();
    }
  }

  function panelMarkup() {
    var pluginTitle = pluginTitleFromStatus();
    return [
      '<div class="skytools-panel-shell">',
      '  <div class="skytools-panel-header">',
      '    <div class="skytools-brand"><span class="skytools-logo"></span><div><strong>' + escapeHtml(pluginTitle) + '</strong><small>Steam integrado</small></div></div>',
      '    <div class="skytools-header-actions"><span class="skytools-status-dot"></span><button class="skytools-panel-restart" type="button" data-action="restart-steam" title="Reiniciar Steam" aria-label="Reiniciar Steam">' + icon("restart", "fa-solid fa-rotate-right") + '</button><button class="skytools-panel-close" type="button" title="Fechar">' + icon("close") + '</button></div>',
      '  </div>',
      '  <div class="skytools-tabs">',
      '    <button type="button" data-tab="inicio">Início</button>',
      '    <button type="button" data-tab="biblioteca">Biblioteca</button>',
      '    <button type="button" data-tab="correcoes">Correções</button>',
      '    <button type="button" data-tab="apis">APIs</button>',
      '    <button type="button" data-tab="backup">Backup</button>',
      '    <button type="button" data-tab="configuracoes">Configurações</button>',
      '  </div>',
      '  <div class="skytools-panel-body"></div>',
      '  <div class="skytools-activity">',
      '    <div class="skytools-activity-icon">' + icon("status") + '</div>',
      '    <div class="skytools-activity-copy"><strong></strong><span></span></div>',
      '    <div class="skytools-progress"><span></span></div>',
      '  </div>',
      '</div>'
    ].join("");
  }

  function updateTabs() {
    var panel = document.querySelector(".skytools-panel");
    if (!panel) {
      return;
    }

    var buttons = panel.querySelectorAll("[data-tab]");
    for (var i = 0; i < buttons.length; i += 1) {
      buttons[i].className = buttons[i].getAttribute("data-tab") === state.activeTab ? "active" : "";
    }
  }

  function resetPanelChromeText(panel) {
    if (!panel) {
      return;
    }
    var subtitle = panel.querySelector(".skytools-brand small");
    if (subtitle) {
      subtitle.textContent = "Steam integrado";
    }
    var close = panel.querySelector(".skytools-panel-close");
    if (close) {
      close.setAttribute("title", "Fechar");
    }
    var restart = panel.querySelector(".skytools-panel-restart");
    if (restart) {
      restart.setAttribute("title", "Reiniciar Steam");
      restart.setAttribute("aria-label", "Reiniciar Steam");
    }
    var labels = {
      inicio: "Início",
      biblioteca: "Biblioteca",
      correcoes: "Correções",
      apis: "APIs",
      backup: "Backup",
      configuracoes: "Configurações"
    };
    var buttons = panel.querySelectorAll("[data-tab]");
    for (var i = 0; i < buttons.length; i += 1) {
      var key = buttons[i].getAttribute("data-tab") || "";
      if (labels[key]) {
        buttons[i].textContent = labels[key];
      }
    }
  }

  function updateActivity() {
    var panel = document.querySelector(".skytools-panel");
    if (!panel) {
      return;
    }

    var activity = panel.querySelector(".skytools-activity");
    var title = panel.querySelector(".skytools-activity-copy strong");
    var detail = panel.querySelector(".skytools-activity-copy span");
    var iconNode = panel.querySelector(".skytools-activity-icon");
    var dot = panel.querySelector(".skytools-status-dot");
    if (activity) {
      activity.className = "skytools-activity skytools-activity-" + state.activityKind;
    }
    if (title) {
      title.textContent = state.activityTitle;
    }
    if (detail) {
      detail.textContent = state.activityDetail;
    }
    if (iconNode) {
      iconNode.innerHTML = icon(state.activityKind === "busy" ? "spinner" : state.activityKind === "success" ? "check" : state.activityKind === "error" ? "error" : "status", state.activityKind === "busy" ? "spin" : "");
    }
    if (dot) {
      dot.className = "skytools-status-dot skytools-dot-" + state.activityKind;
    }
  }

  function updateBusyState() {
    var panel = document.querySelector(".skytools-panel");
    if (!panel) {
      return;
    }

    var actions = panel.querySelectorAll("[data-action]");
    for (var i = 0; i < actions.length; i += 1) {
      actions[i].disabled = state.busy;
    }
  }

  function renderPanelBody() {
    var panel = document.querySelector(".skytools-panel");
    if (!panel) {
      return;
    }
    var body = panel.querySelector(".skytools-panel-body");
    if (body) {
      body.innerHTML = tabMarkup(state.activeTab);
    }
    resetPanelChromeText(panel);
    updateTabs();
    updateActivity();
    updateBusyState();
    localizeDom(panel);
  }

  function renderResult(result, title) {
    state.lastResult = result;

    if (result && result.success === false) {
      setActivity("error", title || "Falha", friendlyError(result));
      showToast("SkyTools", friendlyError(result), "error");
      renderPanelBody();
      return;
    }

    var data = normalizeData(result);
    var detail = "Ação concluída.";
    if (Array.isArray(data)) {
      detail = translateMessage(data.length + " item(ns) encontrados.");
    } else if (data && data.installedCount != null) {
      detail = data.installedCount + " jogos adicionados. Integração: " + (data.integration || "-") + ".";
      if (data.appNameCacheCount != null) {
        detail += " Cache: " + data.appNameCacheCount + " nomes.";
      }
    } else if (data && data.manifestCount != null) {
      detail = "Manifests: " + data.manifestCount + ". DLCs: " + (data.dlcCount || 0) + ".";
    } else if (data && data.message) {
      detail = translateMessage(data.message);
    } else if (data && data.path) {
      detail = data.path;
    }

    setActivity("success", title || "Concluído", detail);
    showToast("SkyTools", detail, "success");
    renderPanelBody();
  }

  function runAction(title, method, payload, after) {
    if (state.busy) {
      showToast("SkyTools", "Aguarde a ação atual terminar.", "info");
      return Promise.resolve();
    }

    setBusy(title, method === "SkyToolsRepair" ? "Executando correção externa..." : "Executando em segundo plano.");
    return call(method, payload).then(function (result) {
      return completeActionResult(title, result, after);
    }, function (error) {
      clearBusy();
      var result = { success: false, error: error && error.message ? error.message : String(error) };
      log(result.error);
      renderResult(result, title);
      return result;
    });
  }

  function completeActionResult(title, result, after) {
    clearBusy();
    if (typeof after === "function" && result && result.success !== false) {
      return Promise.resolve(after(result)).then(function () {
        renderResult(result, title);
        return result;
      });
    }
    renderResult(result, title);
    return Promise.resolve(result);
  }

  function waitForNextPoll(delayMs) {
    return new Promise(function (resolve) {
      window.setTimeout(resolve, delayMs || 1800);
    });
  }

  function pollAsyncAction(title, resultMethod, payload, after, startedAt, timeoutMs) {
    if (Date.now() - startedAt > timeoutMs) {
      clearBusy();
      var timeoutResult = { success: false, error: title + " demorou demais para responder." };
      renderResult(timeoutResult, title);
      return Promise.resolve(timeoutResult);
    }

    return waitForNextPoll(1800).then(function () {
      return call(resultMethod, payload);
    }).then(function (result) {
      if (isPendingResult(result)) {
        var data = normalizeData(result) || {};
        setActivity("busy", title, data.message || "Executando em segundo plano.");
        return pollAsyncAction(title, resultMethod, payload, after, startedAt, timeoutMs);
      }
      return completeActionResult(title, result, after);
    }, function (error) {
      clearBusy();
      var result = { success: false, error: error && error.message ? error.message : String(error) };
      log(result.error);
      renderResult(result, title);
      return result;
    });
  }

  function runAsyncAction(title, startMethod, resultMethod, payload, after) {
    if (state.busy) {
      showToast("SkyTools", "Aguarde a ação atual terminar.", "info");
      return Promise.resolve();
    }

    setBusy(title, "Executando no console oculto.");
    return call(startMethod, payload).then(function (result) {
      if (!isPendingResult(result)) {
        return completeActionResult(title, result, after);
      }
      var data = normalizeData(result) || {};
      setActivity("busy", title, data.message || "Executando no console oculto.");
      return pollAsyncAction(title, resultMethod, payload, after, Date.now(), methodTimeoutMs(startMethod));
    }, function (error) {
      clearBusy();
      var result = { success: false, error: error && error.message ? error.message : String(error) };
      log(result.error);
      renderResult(result, title);
      return result;
    });
  }

  function addCurrentGame(appidOverride) {
    var appid = normalizeAppIdInput(appidOverride || state.addAppIdInput || appIdFromUrl());
    if (!/^[1-9]\d*$/.test(appid)) {
      showToast("SkyTools", "AppID inválido.", "error");
      return;
    }
    state.addAppIdInput = appid;
    var payload = payloadForAppId(appid);
    if (state.addingAppId) {
      showToast("SkyTools", "Aguarde a adição terminar.", "info");
      return Promise.resolve();
    }
    state.addingAppId = String(payload.appid);
    updateGameButton();
    renderPanelBody();
    return runAsyncAction("Adicionando jogo", "SkyToolsAddGame", "SkyToolsAddGameResult", payload, function (result) {
      upsertInstalledFromAddResult(result, payload);
      try {
        localStorage.setItem(PRELOAD_STORAGE_KEY, String(Date.now()));
      } catch (_) {}
      return refreshInstalledCache(true).then(function () {
        updateGameButton();
      });
    }).then(function (result) {
      state.addingAppId = "";
      updateGameButton();
      renderPanelBody();
      return result;
    }, function (error) {
      state.addingAppId = "";
      updateGameButton();
      renderPanelBody();
      throw error;
    });
  }

  function removeCurrentGame() {
    var payload = currentPayload();
    if (!payload.appid) {
      showToast("SkyTools", "Abra a página de um jogo na loja Steam.", "error");
      return;
    }
    return runAction("Removendo jogo", "SkyToolsRemoveGame", payload, function () {
      removeInstalledGameFromState(payload.appid);
    });
  }

  function loadStatus(render) {
    return call("SkyToolsStatus", {}).then(function (result) {
      state.status = result;
      updatePluginTitle();
      syncThemesFromStatus(result);
      syncLanguageFromStatus(result);
      if (render !== false) {
        renderPanelBody();
      }
      return result;
    }, function (error) {
      state.status = { success: false, error: String(error) };
      if (render !== false) {
        renderPanelBody();
      }
    });
  }

  function syncVisualPreferencesFromBackend() {
    if (state.visualPreferenceSyncStarted) {
      return;
    }
    state.visualPreferenceSyncStarted = true;
    window.setTimeout(function () {
      call("SkyToolsStatus", {}).then(function (result) {
        var previousTheme = state.themeId || DEFAULT_THEME;
        state.status = result;
        updatePluginTitle();
        syncThemesFromStatus(result);
        syncLanguageFromStatus(result);
        if ((state.themeId || DEFAULT_THEME) !== previousTheme) {
          applyTheme(state.themeId);
        } else {
          ensureAppliedTheme();
        }
      }, function () {
        ensureAppliedTheme();
      });
    }, 900);
  }

  function readField(panel, name) {
    var input = panel && panel.querySelector('[data-field="' + name + '"]');
    if (!input) {
      return "";
    }
    if (input.type === "checkbox") {
      return input.checked;
    }
    return input.value || "";
  }

  function currentApiForm(panel) {
    var existing = state.apiForm || {};
    return {
      id: existing.id || "",
      native: existing.native === true,
      name: readField(panel, "apiName"),
      urlTemplate: readField(panel, "apiUrl"),
      apiKey: readField(panel, "apiKey"),
      enabled: readField(panel, "apiEnabled") !== false,
      useProxy: readField(panel, "apiUseProxy") === true,
      proxyUrlTemplate: readField(panel, "apiProxyUrl"),
      successCode: Number(readField(panel, "apiSuccessCode")) || 200,
      unavailableCode: Number(readField(panel, "apiUnavailableCode")) || 404
    };
  }

  function apiById(id) {
    var data = normalizeData(state.apis) || {};
    var builtIn = data.builtIn || [];
    var custom = data.custom || [];
    var all = builtIn.concat(custom);
    var wanted = canonicalApiId(id).toLowerCase();
    for (var i = 0; i < all.length; i += 1) {
      if (apiId(all[i]).toLowerCase() === wanted) {
        return all[i];
      }
    }
    return null;
  }

  function setApiOrderOnState(order) {
    var data = normalizeData(state.apis);
    if (data) {
      data.apiOrder = order.slice();
      data.ApiOrder = order.slice();
    }
  }

  function saveApiOrder(order) {
    var nextOrder = Array.isArray(order) && order.length ? order.slice() : (state.apiOrder || []).slice();
    if (!nextOrder.length) {
      return;
    }
    state.apiOrder = nextOrder;
    setApiOrderOnState(nextOrder);
    setActivity("busy", "Salvando ordem", "Atualizando prioridade das APIs...");
    log("SkyTools API order: " + nextOrder.join(","));
    call("SkyToolsSaveApiSettings", {
      apiOrder: nextOrder,
      ApiOrder: nextOrder,
      apiOrderText: nextOrder.join(","),
      apiOrderJson: JSON.stringify(nextOrder)
    }).then(function (result) {
      if (result && result.success === false) {
        renderResult(result, "Falha ao salvar ordem");
        return;
      }
      state.apis = result;
      state.apiOrder = nextOrder;
      writeStoredApiOrder(nextOrder);
      setApiOrderOnState(nextOrder);
      setActivity("success", "Ordem salva", "A prioridade das APIs foi atualizada.");
      renderPanelBody();
    }, function (error) {
      renderResult({ success: false, error: error && error.message ? error.message : String(error) }, "Falha ao salvar ordem");
    });
  }

  function openExternal(url) {
    url = String(url || "").trim();
    if (!url) {
      showToast("SkyTools", "Link indisponível.", "error");
      return;
    }
    window.open(url, "_blank");
  }

  function copyText(text) {
    text = String(text || "");
    if (!text) {
      showToast("SkyTools", "Link indisponível.", "error");
      return;
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () {
        showToast("SkyTools", "Link copiado.", "success");
      }, function () {
        window.prompt("Copie o link:", text);
      });
      return;
    }
    window.prompt("Copie o link:", text);
  }

  function loadFixSources(action, title, payload) {
    return runAction(title, "SkyToolsFixSources", payload, function (result) {
      state.fixResults = result;
      state.activeTab = "correcoes";
    });
  }

  function parseBackupFile(file) {
    if (!file) {
      return;
    }
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var data = JSON.parse(String(reader.result || "{}"));
        var games = Array.isArray(data.games) ? data.games : [];
        if (!games.length) {
          throw new Error("Backup sem jogos.");
        }
        state.backup = data;
        setActivity("success", "Backup carregado", games.length + " jogo(s) no arquivo.");
        renderPanelBody();
      } catch (error) {
        renderResult({ success: false, error: error && error.message ? error.message : String(error) }, "Backup inválido");
      }
    };
    reader.onerror = function () {
      renderResult({ success: false, error: "Não foi possível ler o arquivo." }, "Backup inválido");
    };
    reader.readAsText(file);
  }

  function restoreBackup() {
    if (!state.backup) {
      showToast("SkyTools", "Carregue um arquivo de backup primeiro.", "error");
      return;
    }
    return runAction("Restaurando backup", "SkyToolsBackupRestore", { backup: state.backup }, function () {
      return refreshInstalledCache(true);
    });
  }

  function activateTab(tab) {
    tab = String(tab || "");
    if (!tab) {
      return;
    }
    state.pendingTab = "";
    state.activeTab = tab;
    renderPanelBody();
    ensureTabData(tab);
  }

  function flushPendingTab() {
    if (state.busy || !state.pendingTab) {
      return;
    }
    var pending = state.pendingTab;
    state.pendingTab = "";
    if (pending === state.activeTab) {
      return;
    }
    window.setTimeout(function () {
      if (!document.querySelector(".skytools-panel")) {
        return;
      }
      if (state.busy) {
        state.pendingTab = pending;
        return;
      }
      activateTab(pending);
    }, 0);
  }

  function ensureTabData(tab) {
    if (tab === "biblioteca" && !state.installedLoading) {
      var libraryIsFresh = state.installed !== null
        && state.installedLoadedAt > 0
        && Date.now() - state.installedLoadedAt < LIBRARY_TAB_REFRESH_COOLDOWN;
      if (libraryIsFresh) {
        renderPanelBody();
        return;
      }
      setBusy("Carregando biblioteca", "Carregando jogos adicionados.");
      refreshInstalledCache(true, true).then(function () {
        clearBusy("Biblioteca carregada", gameArray(state.installed).length + " item(ns) encontrados.", "success");
        renderPanelBody();
      }, function (error) {
        clearBusy(false);
        renderResult({
          success: false,
          error: error && error.message ? error.message : String(error)
        }, "Falha");
      });
      return;
    }

    if (tab === "correcoes") {
      var needsFixGames = !state.fixGames;
      var needsFixCatalog = !state.fixCatalogLoadedAt || Date.now() - state.fixCatalogLoadedAt >= 60000;
      if ((needsFixGames || needsFixCatalog) && !state.fixGamesLoading && !state.fixCatalogLoading) {
        setBusy("Buscando correções", "Atualizando jogos e catálogo do GitHub.");
        var loadedFixGames = null;
        refreshFixGames(needsFixGames).then(function (result) {
          loadedFixGames = result;
          return refreshFixCatalog(needsFixCatalog);
        }).then(function (catalogResult) {
          var count = gameArray(loadedFixGames).length;
          if (catalogResult && catalogResult.success === false) {
            clearBusy(false);
            renderResult(catalogResult, "Buscando correções");
            return;
          }
          clearBusy("Jogos instalados carregados", count + " jogo(s) encontrados.", "success");
          renderPanelBody();
        }, function (error) {
          clearBusy(false);
          renderResult({ success: false, error: error && error.message ? error.message : String(error) }, "Falha ao carregar jogos instalados");
        });
      }
      return;
    }

    if (tab === "apis" && !state.apis && !state.apisLoading) {
      setBusy("Carregando APIs", "Sincronizando fontes.");
      refreshApisCache(true).then(function (result) {
        clearBusy("APIs carregadas", "Preferências carregadas.", "success");
        state.apis = result;
        renderPanelBody();
      }, function (error) {
        clearBusy(false);
        renderResult({ success: false, error: error && error.message ? error.message : String(error) }, "Falha ao carregar APIs");
      });
    }
  }

  function preloadStartupData(force) {
    if (state.startupPreloadStarted) {
      return;
    }
    if (!force && !shouldRunStartupPreload()) {
      return;
    }
    state.startupPreloadStarted = true;
    window.setTimeout(function () {
      refreshInstalledCache(force === true)
        .then(function () { return refreshFixGames(force === true); })
        .then(function () { return refreshApisCache(force === true); })
        .then(function () {
        updateGameButton();
        if (document.querySelector(".skytools-panel")) {
          renderPanelBody();
        }
        if (!state.busy) {
          setActivity("idle", "Pronto", "Dados carregados.");
        }
      }, function (error) {
        log("preloadStartupData: " + (error && error.message ? error.message : String(error)));
      });
    }, 1200);
  }

  function openPanel() {
    closePanel();

    var panel = document.createElement("div");
    panel.className = "skytools-panel";
    panel.innerHTML = panelMarkup();
    document.body.appendChild(panel);

    panel.querySelector(".skytools-panel-close").addEventListener("click", closePanel);
    panel.addEventListener("click", function (event) {
      var tab = findTabButton(event.target);
      if (tab) {
        var requestedTab = tab.getAttribute("data-tab");
        if (state.busy) {
          state.pendingTab = requestedTab;
          return;
        }
        activateTab(requestedTab);
        return;
      }

      var button = findActionButton(event.target);
      if (!button) {
        return;
      }
      if (button.disabled) {
        return;
      }

      var action = button.getAttribute("data-action");
      var payload = currentPayload();
      if (action === "restart-steam") {
        markInstalledRefreshOnStart();
        runAction("Reiniciando Steam", "SkyToolsRestartSteam", {});
        return;
      }
      if (action === "add") addCurrentGame();
      if (action === "correcoes-tab") {
        activateTab("correcoes");
      }
      if (action === "refresh-fix-games") {
        state.fixVisibleCount = 80;
        setBusy("Buscando correções", "Atualizando jogos e catálogo do GitHub.");
        refreshFixGames(true).then(function (result) {
          state.fixGames = result;
          return refreshFixCatalog(true);
        }).then(function (catalogResult) {
          state.activeTab = "correcoes";
          if (catalogResult && catalogResult.success === false) {
            clearBusy(false);
            renderResult(catalogResult, "Buscando correções");
            return;
          }
          clearBusy("Concluído", "Lista de correções atualizada.", "success");
          renderPanelBody();
        }, function (error) {
          clearBusy(false);
          renderResult({ success: false, error: error && error.message ? error.message : String(error) }, "Buscando correções");
        });
      }
      if (action === "installed") runAction("Carregando biblioteca", "SkyToolsInstalled", { force: true }, function (result) { applyInstalledResult(result); state.activeTab = "biblioteca"; });
      if (action === "install-game") {
        var installAppid = String(button.getAttribute("data-appid") || "").trim();
        if (/^\d+$/.test(installAppid)) {
          window.location.href = "steam://install/" + installAppid;
        }
        return;
      }
      if (action === "remove-game") runAction("Removendo jogo", "SkyToolsRemoveGame", { appid: button.getAttribute("data-appid"), name: button.getAttribute("data-name") }, function () {
        removeInstalledGameFromState(button.getAttribute("data-appid"));
      });
      if (action === "toggle-update-lock") {
        var currentlyLocked = button.getAttribute("data-locked") === "true";
        runAction(currentlyLocked ? "Destravando atualizações" : "Travando atualizações", "SkyToolsSetUpdateLock", {
          appid: button.getAttribute("data-appid"),
          locked: !currentlyLocked
        }, function (result) {
          var data = normalizeData(result) || {};
          applyInstalledUpdateLock(button.getAttribute("data-appid"), data.locked === true);
          markInstalledRefreshOnStart();
          return call("SkyToolsRestartSteam", {});
        });
      }
      if (action === "toggle-game-settings") {
        var settingsAppid = String(button.getAttribute("data-appid") || "");
        state.gearSpinAppId = settingsAppid;
        state.expandedGameSettingsAppId = String(state.expandedGameSettingsAppId || "") === settingsAppid ? "" : settingsAppid;
        renderPanelBody();
        window.setTimeout(function () {
          if (state.gearSpinAppId === settingsAppid) {
            state.gearSpinAppId = "";
          }
        }, 650);
      }
      if (action === "save-game-settings") {
        var settingsNode = findGameSettingsNode(button);
        if (settingsNode) {
          var settingsId = String(settingsNode.getAttribute("data-game-settings-appid") || "");
          var depotInput = settingsNode.querySelector('[data-game-setting="depot-id"]');
          var manifestInput = settingsNode.querySelector('[data-game-setting="manifest-id"]');
          var depotValue = depotInput ? depotInput.value.trim() : "";
          var manifestValue = manifestInput ? manifestInput.value.trim() : "";
          var manifestEdited = depotValue !== String(depotInput ? depotInput.getAttribute("data-initial-value") || "" : "").trim()
            || manifestValue !== String(manifestInput ? manifestInput.getAttribute("data-initial-value") || "" : "").trim();
          var dlcInputs = settingsNode.querySelectorAll("[data-game-dlc-id]");
          var selectedDlcs = [];
          for (var dlcIndex = 0; dlcIndex < dlcInputs.length; dlcIndex += 1) {
            selectedDlcs.push({
              id: String(dlcInputs[dlcIndex].getAttribute("data-game-dlc-id") || ""),
              enabled: dlcInputs[dlcIndex].checked === true
            });
          }
          runAction("Salvando configurações", "SkyToolsSaveGameSettings", {
            appid: settingsId,
            depotId: depotValue,
            manifestId: manifestValue,
            manifestEdited: manifestEdited,
            dlcs: selectedDlcs
          }, function (result) {
            var savedSettings = normalizeData(result) || {};
            applyInstalledGameSettings(settingsId, savedSettings);
            if (savedSettings.restartRequired === true) {
              markInstalledRefreshOnStart();
              return call("SkyToolsRestartSteam", {});
            }
          });
        }
      }
      if (action === "apis") runAction("Carregando APIs", "SkyToolsApis", {}, function (result) { state.apis = result; state.activeTab = "apis"; });
      if (action === "api-edit") {
        var selectedApi = apiById(button.getAttribute("data-api-id"));
        if (selectedApi) {
          state.apiForm = {
            id: selectedApi.id || selectedApi.Id || "",
            native: selectedApi.native === true || selectedApi.Native === true,
            name: selectedApi.name || selectedApi.Name || "",
            urlTemplate: selectedApi.urlTemplate || selectedApi.UrlTemplate || "",
            apiKey: selectedApi.apiKey || selectedApi.ApiKey || "",
            enabled: selectedApi.enabled !== false && selectedApi.Enabled !== false,
            useProxy: selectedApi.useProxy === true || selectedApi.UseProxy === true,
            proxyUrlTemplate: selectedApi.proxyUrlTemplate || selectedApi.ProxyUrlTemplate || "",
            successCode: selectedApi.successCode || selectedApi.SuccessCode || 200,
            unavailableCode: selectedApi.unavailableCode || selectedApi.UnavailableCode || 404
          };
          renderPanelBody();
        }
      }
      if (action === "api-delete") {
        if (state.busy) {
          showToast("SkyTools", "Aguarde a ação atual terminar.", "info");
          return;
        }
        setBusy("Excluindo API", "Executando em segundo plano.");
        call("SkyToolsDeleteApi", { id: canonicalApiId(button.getAttribute("data-api-id")) }).then(function (result) {
          clearBusy();
          if (result && result.success === false) {
            renderResult(result, "Excluindo API");
            return;
          }
          state.apiForm = null;
          state.apis = null;
          return call("SkyToolsApis", {}).then(function (apis) {
            state.apis = apis;
            renderResult(result, "Excluindo API");
          });
        }, function (error) {
          clearBusy();
          renderResult({ success: false, error: error && error.message ? error.message : String(error) }, "Excluindo API");
        });
      }
      if (action === "api-new") {
        var apiData = normalizeData(state.apis) || {};
        var customCount = (apiData.custom || []).length;
        state.apiForm = { id: "", native: false, name: "API personalizada " + (customCount + 1), urlTemplate: "", apiKey: "", enabled: true, useProxy: false, proxyUrlTemplate: "", successCode: 200, unavailableCode: 404 };
        renderPanelBody();
      }
      if (action === "api-cancel") { state.apiForm = null; renderPanelBody(); }
      if (action === "api-save") {
        if (state.busy) {
          showToast("SkyTools", "Aguarde a ação atual terminar.", "info");
          return;
        }
        var apiPayload = currentApiForm(panel);
        setBusy("Salvando API", "Executando em segundo plano.");
        call("SkyToolsSaveApi", apiPayload).then(function (result) {
          clearBusy();
          if (result && result.success === false) {
            renderResult(result, "Salvando API");
            return;
          }
          state.apiForm = null;
          state.apis = null;
          return call("SkyToolsApis", {}).then(function (apis) {
            state.apis = apis;
            renderResult(result, "Salvando API");
          });
        }, function (error) {
          clearBusy();
          renderResult({ success: false, error: error && error.message ? error.message : String(error) }, "Salvando API");
        });
      }
      if (action === "api-save-settings") runAction("Salvando preferências", "SkyToolsSaveApiSettings", { apiOrder: state.apiOrder || [] }, function (result) { state.apis = result; });
      if (action === "fixes") loadFixSources("fixes", "Buscando correções", payload);
      if (action === "online") loadFixSources("online", "Buscando correções Sky", payload);
      if (action === "denuvo") loadFixSources("denuvo", "Buscando correções Sky", payload);
      if (action === "fix-load-more") {
        var nextLimit = Math.max(80, Number(state.fixVisibleCount || 80));
        if (state.fixMatchedCount && nextLimit >= state.fixMatchedCount) {
          return;
        }
        state.fixVisibleCount = nextLimit + 120;
        var loadMoreList = panel.querySelector('[data-role="fix-game-list"]');
        if (loadMoreList) {
          loadMoreList.innerHTML = renderFixGamePicker();
          localizeDom(loadMoreList);
        }
      }
      if (action === "fix-open") openExternal(button.getAttribute("data-url"));
      if (action === "fix-copy") copyText(button.getAttribute("data-url"));
      if (action === "fix-game") {
        state.selectedFixGame = {
          appid: button.getAttribute("data-appid") || "",
          name: button.getAttribute("data-name") || "",
          gamePath: button.getAttribute("data-game-path") || ""
        };
        loadFixSources("fixes", "Buscando correções Sky", state.selectedFixGame);
      }
      if (action === "fix-remove") {
        var removeAppid = button.getAttribute("data-appid") || "";
        var removeName = button.getAttribute("data-name") || "";
        runAction("Removendo correção", "SkyToolsRemoveFix", {
          appid: removeAppid,
          name: removeName
        }, function (result) {
          var data = normalizeData(result) || {};
          var validateUrl = data.validateUrl || ("steam://validate/" + removeAppid);
          try {
            window.location.href = validateUrl;
          } catch (_) {}
          return refreshInstalledCache(true).then(function (fresh) {
            state.fixGames = fresh;
          });
        });
      }
      if (action === "fix-prepare") {
        var source = sourceArray(state.fixResults)[Number(button.getAttribute("data-source-index") || 0)];
        var selected = state.selectedFixGame || payload;
        var sourceJson = JSON.stringify(source || {});
        var fixPayload = {
          appid: selected.appid,
          name: selected.name,
          gamePath: selected.gamePath || "",
          source: source || {},
          sourceJson: sourceJson,
          downloadUrl: sourceUrl(source || {}),
          sourceName: source && (source.name || source.title) || "",
          sourceType: source && source.type || "",
          sourceKind: source && source.kind || "",
          fileName: source && (source.fileName || source.filename || "") || "",
          displayName: source && source.displayName || "",
          provider: source && source.provider || "",
          size: source && source.size || ""
        };
        runAsyncAction("Aplicando Correção", "SkyToolsApplyFix", "SkyToolsApplyFixResult", fixPayload, function (result) {
          var data = normalizeData(result) || {};
          if (data.action === "copy" && data.url) {
            copyText(data.url);
          }
        });
      }
      if (action === "backup") { state.activeTab = "backup"; renderPanelBody(); }
      if (action === "backup-export") runAction("Exportando backup", "SkyToolsBackupExport", {});
      if (action === "backup-restore") restoreBackup();
      if (action === "integration-skytools") runAction("Ativando SkyTools", "SkyToolsIntegration", { target: "SkyTools" }, function (result) { state.status = result; });
      if (action === "integration-steamtools") runAction("Ativando SteamTools", "SkyToolsIntegration", { target: "SteamTools" }, function (result) { state.status = result; });
      if (action === "status") runAction("Coletando configurações", "SkyToolsStatus", {}, function (result) { state.status = result; syncThemesFromStatus(result); syncLanguageFromStatus(result); });
    });

    panel.addEventListener("change", function (event) {
      if (event.target && event.target.getAttribute && event.target.getAttribute("data-field") === "languageSelect") {
        state.languageMode = normalizeLanguageId(event.target.value || DEFAULT_LANGUAGE);
        writeStoredLanguage(state.languageMode);
        updateGameButton();
        renderPanelBody();
        setBusy("Salvando idioma", "Executando em segundo plano.");
        call("SkyToolsSaveApiSettings", { selectedLanguage: state.languageMode, language: state.languageMode }).then(function (result) {
          clearBusy("Idioma aplicado", "Preferência salva.", "success");
          if (result && result.success === false) {
            setActivity("error", "Idioma aplicado", "Não foi possível salvar o idioma.");
          }
        }, function (error) {
          clearBusy(false);
          setActivity("error", "Idioma aplicado", error && error.message ? error.message : "Não foi possível salvar o idioma.");
        });
        return;
      }
      if (event.target && event.target.getAttribute && event.target.getAttribute("data-field") === "themeSelect") {
        state.themeId = event.target.value || DEFAULT_THEME;
        writeStoredTheme(state.themeId);
        var selectedTheme = themeById(state.themeId);
        applyTheme(state.themeId).then(function (result) {
          if (result && result.success === false) {
            setActivity("error", "Tema não aplicado", result.error || "Voltando ao tema oficial.");
            return;
          }
          saveThemePreference(selectedTheme.id).then(function (saveResult) {
            if (saveResult && saveResult.success === false) {
              setActivity("error", "Tema aplicado", "Não foi possível salvar para a próxima inicialização.");
              return;
            }
            setActivity("success", "Tema aplicado", selectedTheme.name || "Tema selecionado.");
          });
        });
      }
      var actionNode = findActionButton(event.target);
      if (actionNode && actionNode.getAttribute("data-action") === "backup-file") {
        var fileNameNode = panel.querySelector('[data-role="backup-file-name"]');
        if (fileNameNode) {
          fileNameNode.textContent = actionNode.files && actionNode.files[0] ? actionNode.files[0].name : t("Nenhum arquivo escolhido");
        }
        parseBackupFile(actionNode.files && actionNode.files[0]);
      }
    });

    panel.addEventListener("input", function (event) {
      if (event.target && event.target.getAttribute && event.target.getAttribute("data-field") === "addGameAppId") {
        var appid = normalizeAppIdInput(event.target.value);
        if (event.target.value !== appid) {
          event.target.value = appid;
        }
        state.addAppIdInput = appid;
      }
      if (event.target && event.target.getAttribute && event.target.getAttribute("data-field") === "fixSearch") {
        state.fixQuery = event.target.value || "";
        state.fixVisibleCount = 80;
        var fixList = panel.querySelector('[data-role="fix-game-list"]');
        if (fixList) {
          fixList.innerHTML = renderFixGamePicker();
          localizeDom(fixList);
        }
      }
      if (event.target && event.target.getAttribute && event.target.getAttribute("data-field") === "librarySearch") {
        state.libraryQuery = event.target.value || "";
        var installedList = panel.querySelector('[data-role="installed-list"]');
        if (installedList) {
          installedList.innerHTML = renderInstalledList();
          localizeDom(installedList);
        }
      }
    });

    panel.addEventListener("keydown", function (event) {
      if (event.key === "Enter"
          && event.target
          && event.target.getAttribute
          && event.target.getAttribute("data-field") === "addGameAppId") {
        event.preventDefault();
        if (!state.busy && !state.addingAppId) {
          addCurrentGame();
        }
      }
    });

    panel.addEventListener("scroll", function (event) {
      var target = event.target;
      if (!target || !target.getAttribute || target.getAttribute("data-role") !== "fix-game-list") {
        return;
      }
      if (target.scrollTop + target.clientHeight < target.scrollHeight - 72) {
        return;
      }
      var oldLimit = Number(state.fixVisibleCount || 80);
      if (state.fixMatchedCount && oldLimit >= state.fixMatchedCount) {
        return;
      }
      state.fixVisibleCount = oldLimit + 120;
      var oldTop = target.scrollTop;
      target.innerHTML = renderFixGamePicker();
      localizeDom(target);
      target.scrollTop = oldTop;
    }, true);

    panel.addEventListener("mousedown", function (event) {
      if (event.target && event.target.closest && event.target.closest(".skytools-row-actions,button,input,textarea,select")) {
        return;
      }
      var row = event.target && event.target.closest ? event.target.closest(".skytools-api-draggable") : null;
      if (!row) {
        return;
      }
      row.draggable = true;
    });

    panel.addEventListener("mouseup", function (event) {
      var row = event.target && event.target.closest ? event.target.closest(".skytools-api-draggable") : null;
      if (row) {
        row.draggable = true;
      }
    });

    panel.addEventListener("dragstart", function (event) {
      var row = event.target && event.target.closest ? event.target.closest(".skytools-api-draggable") : null;
      if (!row || (event.target && event.target.closest && event.target.closest(".skytools-row-actions,button,input,textarea,select"))) {
        return;
      }
      row.draggable = true;
      state.draggingApiId = row.getAttribute("data-api-id") || "";
      state.pendingApiDrop = null;
      row.classList.add("dragging");
      if (event.dataTransfer) {
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", state.draggingApiId);
      }
    });

    panel.addEventListener("dragover", function (event) {
      var target = event.target && event.target.closest ? event.target.closest(".skytools-api-draggable") : null;
      var dragging = panel.querySelector(".skytools-api-draggable.dragging");
      if (!target || !dragging || target === dragging) {
        return;
      }
      event.preventDefault();
      if (event.dataTransfer) {
        event.dataTransfer.dropEffect = "move";
      }
      var rect = target.getBoundingClientRect();
      var afterTarget = event.clientY > rect.top + (rect.height / 2);
      state.pendingApiDrop = {
        targetId: target.getAttribute("data-api-id") || "",
        afterTarget: afterTarget
      };
      target.parentNode.insertBefore(dragging, afterTarget ? target.nextSibling : target);
    });

    panel.addEventListener("drop", function (event) {
      var dragging = panel.querySelector(".skytools-api-draggable.dragging");
      if (dragging) {
        event.preventDefault();
        var target = event.target && event.target.closest ? event.target.closest(".skytools-api-draggable") : null;
        if (target && target !== dragging && target.parentNode) {
          var rect = target.getBoundingClientRect();
          var afterTarget = event.clientY > rect.top + (rect.height / 2);
          state.pendingApiDrop = {
            targetId: target.getAttribute("data-api-id") || "",
            afterTarget: afterTarget
          };
          target.parentNode.insertBefore(dragging, afterTarget ? target.nextSibling : target);
        }
      }
    });

    panel.addEventListener("dragend", function () {
      var dragging = panel.querySelector(".skytools-api-draggable.dragging");
      if (!dragging) {
        return;
      }
      dragging.classList.remove("dragging");
      dragging.draggable = true;
      var order = collectApiOrderFromDom(panel);
      if (state.pendingApiDrop && state.pendingApiDrop.targetId) {
        if (reorderApiOrder(state.draggingApiId, state.pendingApiDrop.targetId, state.pendingApiDrop.afterTarget === true)) {
          order = (state.apiOrder || []).slice();
        }
      }
      state.draggingApiId = "";
      state.pendingApiDrop = null;
      state.draggingPointerId = null;
      saveApiOrder(order);
    });

    renderPanelBody();
    setActivity("busy", "Carregando status", "Sincronizando com o backend...");
    (state.status ? Promise.resolve(state.status) : loadStatus(true)).then(function () {
      if (!state.installed && state.activeTab === "biblioteca") {
        return refreshInstalledCache(false);
      }
      if (!state.fixGames && state.activeTab === "correcoes") {
        return refreshFixGames(false);
      }
      return state.activeTab === "correcoes" ? state.fixGames : state.installed;
    }).then(function () {
      renderPanelBody();
      if (!state.busy) {
        setActivity("idle", "Pronto", "SkyTools carregado.");
      }
      ensureTabData(state.activeTab);
    });
  }

  function tick() {
    var addInputChanged = syncAddAppIdFromPage();
    ensureAppliedTheme();
    removeLegacyWebkitButton();
    ensureFloatingMenu();
    updateFloatingMenu();
    ensureGameButton();
    ensureGameIndicators();
    var payload = currentPayload();
    var changed = payload.appid !== state.appid || payload.name !== state.appName;
    state.appid = payload.appid;
    state.appName = payload.name;
    if ((changed || addInputChanged) && document.querySelector(".skytools-panel")) {
      renderPanelBody();
    }
  }

  function isSkyToolsOwnedNode(node) {
    if (!node || node.nodeType !== 1) {
      return false;
    }
    if ((node.id && node.id.indexOf("skytools-") === 0) ||
        (node.classList && Array.prototype.some.call(node.classList, function (name) {
          return String(name).indexOf("skytools-") === 0;
        }))) {
      return true;
    }
    return !!(node.closest && node.closest(
      "#skytools-theme-style,#skytools-theme-link,.skytools-panel,.skytools-fab-shell,.skytools-toast,.skytools-game-button,.skytools-game-indicators"
    ));
  }

  function mutationNeedsTick(records) {
    for (var recordIndex = 0; recordIndex < records.length; recordIndex += 1) {
      var record = records[recordIndex];
      if (isSkyToolsOwnedNode(record.target)) {
        continue;
      }
      var changedNodes = [];
      changedNodes = changedNodes.concat(Array.prototype.slice.call(record.addedNodes || []));
      changedNodes = changedNodes.concat(Array.prototype.slice.call(record.removedNodes || []));
      if (!changedNodes.length) {
        return true;
      }
      for (var nodeIndex = 0; nodeIndex < changedNodes.length; nodeIndex += 1) {
        if (!isSkyToolsOwnedNode(changedNodes[nodeIndex])) {
          return true;
        }
      }
    }
    return false;
  }

  function boot() {
    try {
      console.log("[SkyTools] browser script loaded:", location.href);
    } catch (_) {}
    state.lastUrl = location.href;
    applyTheme(state.themeId);
    syncVisualPreferencesFromBackend();
    if (consumeInstalledRefreshOnStart()) {
      preloadStartupData(true);
    }
    tick();
    if (window.__skytoolsTickInterval) {
      window.clearInterval(window.__skytoolsTickInterval);
    }
    window.__skytoolsTickInterval = window.setInterval(function () {
      if (location.href !== state.lastUrl) {
        state.lastUrl = location.href;
        removeGameButton();
        removeGameIndicators();
        state.indicatorCatalogAppId = "";
        ensureAppliedTheme();
        window.clearTimeout(window.__skytoolsNavigationTimer);
        window.__skytoolsNavigationTimer = window.setTimeout(function () {
          window.__skytoolsNavigationTimer = null;
          ensureAppliedTheme();
          tick();
        }, 350);
      } else {
        tick();
      }
    }, 1800);

    var observer = new MutationObserver(function (records) {
      if (!mutationNeedsTick(records || [])) {
        return;
      }
      window.clearTimeout(window.__skytoolsObserverTimer);
      window.__skytoolsObserverTimer = window.setTimeout(function () {
        window.__skytoolsObserverTimer = null;
        ensureAppliedTheme();
        tick();
      }, 350);
    });
    if (window.__skytoolsObserver && window.__skytoolsObserver.disconnect) {
      window.__skytoolsObserver.disconnect();
    }
    window.__skytoolsObserver = observer;
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
