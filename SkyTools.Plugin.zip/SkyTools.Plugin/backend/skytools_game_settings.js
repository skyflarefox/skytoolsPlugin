// SkyTools per-game Lua settings editor for Windows Script Host.
(function () {
  var fso = new ActiveXObject("Scripting.FileSystemObject");

  function arg(index) {
    return WScript.Arguments.length > index ? String(WScript.Arguments.Item(index)) : "";
  }

  function ensureDir(path) {
    if (!path || fso.FolderExists(path)) return;
    var parent = fso.GetParentFolderName(path);
    if (parent && !fso.FolderExists(parent)) ensureDir(parent);
    if (!fso.FolderExists(path)) fso.CreateFolder(path);
  }

  function readTextWithCharset(path, charset) {
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 2;
    stream.Charset = charset;
    stream.Open();
    stream.LoadFromFile(path);
    var text = stream.ReadText();
    stream.Close();
    return text;
  }

  function readText(path) {
    var charsets = ["utf-8", "windows-1252", "unicode"];
    for (var i = 0; i < charsets.length; i += 1) {
      try {
        return readTextWithCharset(path, charsets[i]);
      } catch (_) {
      }
    }
    var file = fso.OpenTextFile(path, 1, false);
    var text = file.ReadAll();
    file.Close();
    return text;
  }

  function writeUtf8NoBom(path, text) {
    ensureDir(fso.GetParentFolderName(path));
    var textStream = new ActiveXObject("ADODB.Stream");
    textStream.Type = 2;
    textStream.Charset = "utf-8";
    textStream.Open();
    textStream.WriteText(String(text || ""));
    textStream.Position = 0;
    textStream.Type = 1;
    if (textStream.Size >= 3) textStream.Position = 3;

    var binaryStream = new ActiveXObject("ADODB.Stream");
    binaryStream.Type = 1;
    binaryStream.Open();
    textStream.CopyTo(binaryStream);
    binaryStream.SaveToFile(path, 2);
    binaryStream.Close();
    textStream.Close();
  }

  function jsonEscape(value) {
    return String(value == null ? "" : value)
      .replace(/\\/g, "\\\\")
      .replace(/"/g, "\\\"")
      .replace(/\r/g, "\\r")
      .replace(/\n/g, "\\n")
      .replace(/\t/g, "\\t");
  }

  function dlcArrayJson(values) {
    var parts = [];
    for (var i = 0; i < values.length; i += 1) {
      parts.push("{"
        + "\"id\":\"" + jsonEscape(values[i].id) + "\","
        + "\"enabled\":" + (values[i].enabled ? "true" : "false") + ","
        + "\"label\":\"" + jsonEscape(values[i].label || "") + "\""
        + "}");
    }
    return "[" + parts.join(",") + "]";
  }

  function stringArrayJson(values) {
    var parts = [];
    for (var i = 0; i < values.length; i += 1) {
      parts.push("\"" + jsonEscape(values[i]) + "\"");
    }
    return "[" + parts.join(",") + "]";
  }

  function writeResult(path, success, data, error) {
    ensureDir(fso.GetParentFolderName(path));
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 2;
    stream.Charset = "utf-8";
    stream.Open();
    stream.WriteText("{"
      + "\"success\":" + (success ? "true" : "false") + ","
      + "\"data\":" + (data || "{}") + ","
      + "\"error\":\"" + jsonEscape(error || "") + "\""
      + "}");
    stream.SaveToFile(path, 2);
    stream.Close();
  }

  function escapeRegex(value) {
    return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }

  function uncommentLine(line, indent) {
    var content = line.slice(indent.length + 2);
    if (/^[ \t]/.test(content)) content = content.slice(1);
    return indent + content;
  }

  function setCallEnabled(line, callName, id, enabled) {
    var escapedId = escapeRegex(id);
    var active = line.match(new RegExp("^(\\s*)" + callName + "\\s*\\(\\s*" + escapedId + "(?:\\s*[,\\)])", "i"));
    var commented = active ? null : line.match(new RegExp("^(\\s*)--\\s*" + callName + "\\s*\\(\\s*" + escapedId + "(?:\\s*[,\\)])", "i"));
    if (enabled && commented) return uncommentLine(line, commented[1] || "");
    if (!enabled && active) return active[1] + "-- " + line.slice(active[1].length);
    return line;
  }

  function maskLuaBlockComments(text) {
    return String(text || "").replace(/--\[(=*)\[[\s\S]*?\]\1\]/g, function (block) {
      return block.replace(/[^\r\n]/g, " ");
    });
  }

  function appendLuaLine(text, line, newline) {
    var output = String(text || "");
    if (output.length > 0 && !/[\r\n]$/.test(output)) {
      output += newline;
    }
    return output + line + newline;
  }

  function insertManifestAfterDepotKey(lines, depotId, manifestId) {
    var escapedId = escapeRegex(depotId);
    var activeKeyPattern = new RegExp(
      "^\\s*addappid\\s*\\(\\s*" + escapedId + "\\s*,[^\\r\\n)]*,\\s*[\"'][^\"']+[\"']",
      "i"
    );
    var commentedKeyPattern = new RegExp(
      "^\\s*--\\s*addappid\\s*\\(\\s*" + escapedId + "\\s*,[^\\r\\n)]*,\\s*[\"'][^\"']+[\"']",
      "i"
    );
    var fallbackPattern = new RegExp(
      "^\\s*(?:--\\s*)?addappid\\s*\\(\\s*" + escapedId + "(?:\\s*[,\\)])",
      "i"
    );
    var insertionIndex = -1;
    var fallbackIndex = -1;
    for (var i = 0; i < lines.length; i += 1) {
      if (activeKeyPattern.test(lines[i])) {
        insertionIndex = i;
        break;
      }
      if (insertionIndex < 0 && commentedKeyPattern.test(lines[i])) {
        insertionIndex = i;
      }
      if (fallbackIndex < 0 && fallbackPattern.test(lines[i])) {
        fallbackIndex = i;
      }
    }
    if (insertionIndex < 0) insertionIndex = fallbackIndex;
    if (insertionIndex < 0) return false;

    var indent = (lines[insertionIndex].match(/^(\s*)/) || ["", ""])[1];
    lines.splice(insertionIndex + 1, 0, indent + 'setManifestid(' + depotId + ', "' + manifestId + '")');
    return true;
  }

  function splitInlineManifestLines(lines) {
    var changed = false;
    var pattern = /^(.*?\))[ \t]+(setmanifestid\s*\(\s*\d+\s*,.*)$/i;
    for (var i = 0; i < lines.length; i += 1) {
      var match = lines[i].match(pattern);
      if (!match) continue;
      lines[i] = match[1];
      lines.splice(i + 1, 0, match[2]);
      changed = true;
      i += 1;
    }
    return changed;
  }

  function scanState(lines, appid, preferredDepotId) {
    var state = {
      dlcs: [],
      activeManifestDepotIds: [],
      luaDepotId: "",
      luaManifestId: "",
      updatesLocked: false
    };
    var dlcMap = {};
    var manifestSeen = {};
    var manifests = [];

    var visibleLines = maskLuaBlockComments(lines.join("\n")).split("\n");
    for (var i = 0; i < lines.length; i += 1) {
      var line = visibleLines[i] || "";
      var commentedDlc = line.match(/^\s*--\s*addappid\s*\(\s*(\d+)/i);
      var activeDlc = commentedDlc ? null : line.match(/^\s*addappid\s*\(\s*(\d+)/i);
      var dlcMatch = activeDlc || commentedDlc;
      if (dlcMatch) {
        var dlcId = String(dlcMatch[1]);
        if (dlcId !== String(appid)) {
          var labelMatch = String(lines[i] || "").match(/\)\s*--\s*(.+)\s*$/);
          var label = labelMatch ? String(labelMatch[1]).replace(/^\s+|\s+$/g, "") : "";
          if (!dlcMap[dlcId]) {
            dlcMap[dlcId] = { id: dlcId, enabled: !!activeDlc, label: label, lineIndexes: [i] };
            state.dlcs.push(dlcMap[dlcId]);
          } else {
            dlcMap[dlcId].lineIndexes.push(i);
            if (activeDlc) dlcMap[dlcId].enabled = true;
          }
        }
      }

      var commentedManifest = line.match(/^\s*--\s*setmanifestid\s*\(\s*(\d+)\s*,\s*["']?(\d+)["']?/i);
      var activeManifest = commentedManifest ? null : line.match(/^\s*setmanifestid\s*\(\s*(\d+)\s*,\s*["']?(\d+)["']?/i);
      var manifestMatch = activeManifest || commentedManifest;
      if (manifestMatch) {
        var depotId = String(manifestMatch[1]);
        manifests.push({
          depotId: depotId,
          manifestId: String(manifestMatch[2]),
          enabled: !!activeManifest,
          lineIndex: i
        });
        if (activeManifest && !manifestSeen[depotId]) {
          manifestSeen[depotId] = true;
          state.activeManifestDepotIds.push(depotId);
        }
      }
    }

    var preferred = String(preferredDepotId || (Number(appid) + 1));
    var selected = null;
    for (var p = 0; p < manifests.length; p += 1) {
      if (manifests[p].depotId === preferred) {
        selected = manifests[p];
        break;
      }
    }
    if (!selected) {
      for (var m = 0; m < manifests.length; m += 1) {
        if (!dlcMap[manifests[m].depotId]) {
          selected = manifests[m];
          break;
        }
      }
    }
    if (selected) {
      state.luaDepotId = selected.depotId;
      state.luaManifestId = selected.manifestId;
      state.updatesLocked = selected.enabled;
      state.mainLineIndex = selected.lineIndex;
    }
    state.dlcMap = dlcMap;
    return state;
  }

  var resultPath = arg(0);
  var requestPath = arg(1);
  var scriptPath = arg(2);
  var appid = arg(3);

  try {
    if (!resultPath) throw new Error("Caminho de resultado ausente.");
    if (!requestPath || !fso.FileExists(requestPath)) throw new Error("Configuração temporária não encontrada.");
    if (!scriptPath || !fso.FileExists(scriptPath)) throw new Error("Arquivo Lua do jogo não encontrado.");
    if (!/^\d+$/.test(appid)) throw new Error("AppID inválido.");

    var request = eval("(" + readText(requestPath) + ")");
    var depotId = String(request.depotId || "").replace(/^\s+|\s+$/g, "");
    var manifestId = String(request.manifestId || "").replace(/^\s+|\s+$/g, "");
    var currentDepotId = String(request.currentDepotId || "").replace(/^\s+|\s+$/g, "");
    var currentManifestId = String(request.currentManifestId || "").replace(/^\s+|\s+$/g, "");
    var manifestEdited = request.manifestEdited === true;
    if ((depotId && !manifestId) || (!depotId && manifestId)) {
      throw new Error("Informe DepotID e ManifestID juntos.");
    }
    if (depotId && !/^\d+$/.test(depotId)) throw new Error("DepotID inválido.");
    if (manifestId && !/^\d+$/.test(manifestId)) throw new Error("ManifestID inválido.");

    var original = readText(scriptPath);
    var newline = original.indexOf("\r\n") >= 0 ? "\r\n" : "\n";
    var lines = original.split(/\r\n|\n|\r/);
    var changed = splitInlineManifestLines(lines);
    var before = scanState(lines, appid, depotId || currentDepotId);
    var requestedDlcs = request.dlcs instanceof Array ? request.dlcs : [];

    for (var d = 0; d < requestedDlcs.length; d += 1) {
      var requestedId = String(requestedDlcs[d].id || "");
      if (!/^\d+$/.test(requestedId) || !before.dlcMap[requestedId]) continue;
      var requestedEnabled = requestedDlcs[d].enabled === true;
      var lineIndexes = before.dlcMap[requestedId].lineIndexes || [];
      for (var lineOffset = 0; lineOffset < lineIndexes.length; lineOffset += 1) {
        var lineIndex = lineIndexes[lineOffset];
        var updatedDlcLine = setCallEnabled(lines[lineIndex], "addappid", requestedId, requestedEnabled);
        if (updatedDlcLine !== lines[lineIndex]) {
          lines[lineIndex] = updatedDlcLine;
          changed = true;
        }
      }
    }

    if (manifestEdited) {
      var selectedLine = -1;
      if (depotId && manifestId) {
        var editableLines = maskLuaBlockComments(lines.join("\n")).split("\n");
        for (var exactIndex = 0; exactIndex < lines.length; exactIndex += 1) {
          if (new RegExp("^\\s*(?:--\\s*)?setmanifestid\\s*\\(\\s*" + escapeRegex(depotId) + "\\s*,", "i").test(editableLines[exactIndex] || "")) {
            selectedLine = exactIndex;
            break;
          }
        }
      }
      if (selectedLine < 0 && before.mainLineIndex !== undefined) {
        selectedLine = before.mainLineIndex;
      }

      var hasCurrentManifest = !!(currentDepotId && currentManifestId);
      var shouldLockManifest = !!(depotId && manifestId)
        && (!hasCurrentManifest || depotId !== currentDepotId || manifestId !== currentManifestId);

      if (selectedLine >= 0 && depotId && manifestId) {
        var manifestLine = lines[selectedLine];
        var callPattern = /(setmanifestid\s*\(\s*)\d+(\s*,\s*)(["']?)\d+\3/i;
        manifestLine = manifestLine.replace(callPattern, function (_, prefix, separator) {
          return prefix + depotId + separator + '"' + manifestId + '"';
        });
        var indent = (manifestLine.match(/^(\s*)/) || ["", ""])[1];
        var commented = manifestLine.match(/^\s*--\s*setmanifestid/i);
        if (shouldLockManifest && commented) {
          manifestLine = uncommentLine(manifestLine, indent);
        } else if (!shouldLockManifest && !commented && /^\s*setmanifestid/i.test(manifestLine)) {
          manifestLine = indent + "-- " + manifestLine.slice(indent.length);
        }
        if (manifestLine !== lines[selectedLine]) {
          lines[selectedLine] = manifestLine;
          changed = true;
        }
      } else if (selectedLine >= 0 && !depotId && !manifestId) {
        var clearedLine = lines[selectedLine];
        var clearedIndent = (clearedLine.match(/^(\s*)/) || ["", ""])[1];
        if (/^\s*setmanifestid/i.test(clearedLine)) {
          lines[selectedLine] = clearedIndent + "-- " + clearedLine.slice(clearedIndent.length);
          changed = true;
        }
      } else if (depotId && manifestId && shouldLockManifest) {
        if (!insertManifestAfterDepotKey(lines, depotId, manifestId)) {
          original = appendLuaLine(lines.join(newline), 'setManifestid(' + depotId + ', "' + manifestId + '")', newline);
          lines = original.split(/\r\n|\n|\r/);
        }
        changed = true;
      }
    }

    if (changed) writeUtf8NoBom(scriptPath, lines.join(newline));
    var after = scanState(readText(scriptPath).split(/\r\n|\n|\r/), appid, depotId || currentDepotId);
    writeResult(resultPath, true, "{"
      + "\"changed\":" + (changed ? "true" : "false") + ","
      + "\"luaDepotId\":\"" + jsonEscape(after.luaDepotId) + "\","
      + "\"luaManifestId\":\"" + jsonEscape(after.luaManifestId) + "\","
      + "\"updatesLocked\":" + (after.updatesLocked ? "true" : "false") + ","
      + "\"activeManifestDepotIds\":" + stringArrayJson(after.activeManifestDepotIds) + ","
      + "\"dlcs\":" + dlcArrayJson(after.dlcs)
      + "}", "");
  } catch (error) {
    writeResult(resultPath, false, "{}", error && error.message ? error.message : String(error));
  }
})();
