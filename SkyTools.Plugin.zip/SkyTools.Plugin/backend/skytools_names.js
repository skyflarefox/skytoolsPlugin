// SkyTools app-name resolver. Receives result path followed by AppIDs.
(function () {
  var fso = new ActiveXObject("Scripting.FileSystemObject");

  function arg(index) {
    return WScript.Arguments.length > index ? String(WScript.Arguments.Item(index)) : "";
  }

  function ensureDir(path) {
    if (!path || fso.FolderExists(path)) return;
    var parent = fso.GetParentFolderName(path);
    if (parent && !fso.FolderExists(parent)) ensureDir(parent);
    if (!fso.FolderExists(path)) fso.CreateFolder(path);
  }

  function writeText(path, text) {
    ensureDir(fso.GetParentFolderName(path));
    var stream = new ActiveXObject("ADODB.Stream");
    stream.Type = 2;
    stream.Charset = "utf-8";
    stream.Open();
    stream.WriteText(String(text || ""));
    stream.SaveToFile(path, 2);
    stream.Close();
  }

  function jsonEscape(value) {
    return String(value == null ? "" : value)
      .replace(/\\/g, "\\\\")
      .replace(/"/g, "\\\"")
      .replace(/\r/g, "\\r")
      .replace(/\n/g, "\\n")
      .replace(/\t/g, "\\t");
  }

  function uniqueAppIds() {
    var seen = {};
    var ids = [];
    for (var i = 1; i < WScript.Arguments.length; i += 1) {
      var id = String(arg(i)).replace(/\D/g, "");
      if (id && !seen[id]) {
        seen[id] = true;
        ids.push(id);
      }
    }
    return ids;
  }

  function cleanName(value, id) {
    var name = String(value || "")
      .replace(/&amp;/gi, "&")
      .replace(/&quot;/gi, "\"")
      .replace(/&#39;|&apos;/gi, "'")
      .replace(/&lt;/gi, "<")
      .replace(/&gt;/gi, ">")
      .replace(/[\x00-\x1f\x7f]/g, " ")
      .replace(/\s+/g, " ")
      .replace(/^\s+|\s+$/g, "");
    if (!name || /^\d+$/.test(name) || name.toLowerCase() === ("appid " + id).toLowerCase()) return "";
    return name.length > 180 ? name.substring(0, 180) : name;
  }

  function requestJson(url) {
    var http = new ActiveXObject("MSXML2.ServerXMLHTTP.6.0");
    try {
      http.setTimeouts(3500, 3500, 5000, 7000);
      http.open("GET", url, false);
      http.setRequestHeader("User-Agent", "SkyToolsPlugin/1.4");
      http.setRequestHeader("Accept", "application/json,*/*");
      http.send();
      if (http.status < 200 || http.status >= 300) return null;
      return (new Function("return (" + String(http.responseText || "{}") + ");"))();
    } catch (_) {
      return null;
    }
  }

  function storeName(id) {
    var data = requestJson("https://store.steampowered.com/api/appdetails?filters=basic&appids=" + encodeURIComponent(id));
    var item = data && data[id] ? data[id] : null;
    return cleanName(item && item.success && item.data ? item.data.name : "", id);
  }

  function steamCmdName(id) {
    var data = requestJson("https://api.steamcmd.net/v1/info/" + encodeURIComponent(id));
    var root = data && data.status === "success" && data.data ? data.data : null;
    var item = root ? (root[id] || root[Number(id)]) : null;
    if (!item) return "";
    var common = item.common || {};
    var config = item.config || {};
    var extended = item.extended || {};
    return cleanName(common.name || config.installdir || extended.game || "", id);
  }

  function steamSpyName(id) {
    var data = requestJson("https://steamspy.com/api.php?request=appdetails&appid=" + encodeURIComponent(id));
    return cleanName(data && data.name ? data.name : "", id);
  }

  function fetchNames(ids) {
    var names = {};
    for (var i = 0; i < ids.length; i += 1) {
      var id = ids[i];
      var name = storeName(id) || steamCmdName(id) || steamSpyName(id);
      if (name) names[id] = name;
    }
    return names;
  }

  try {
    var resultPath = arg(0);
    var ids = uniqueAppIds();
    var names = fetchNames(ids);
    var parts = [];
    for (var id in names) {
      if (Object.prototype.hasOwnProperty.call(names, id)) {
        parts.push("\"" + jsonEscape(id) + "\":\"" + jsonEscape(names[id]) + "\"");
      }
    }
    writeText(resultPath, "{\"success\":true,\"data\":{" + parts.join(",") + "},\"error\":\"\"}");
  } catch (error) {
    writeText(arg(0), "{\"success\":false,\"error\":\"" + jsonEscape(error && error.message ? error.message : String(error)) + "\"}");
  }
})();
